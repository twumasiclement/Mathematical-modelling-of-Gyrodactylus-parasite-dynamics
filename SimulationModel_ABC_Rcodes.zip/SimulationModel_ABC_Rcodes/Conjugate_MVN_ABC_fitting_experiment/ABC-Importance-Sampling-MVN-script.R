ABC<- function(fork,pftn,n1,w){
  number_of_parameters<-6
  dimS<- length(summaries_obs)#dimension of summaries
  theta  <- matrix(nrow = n1, ncol = number_of_parameters)# matrix of prior distributions
  d <- rep(NA, n1)# weighted distance
  w<- w/sum(w) #normalized weighted for computing distance
  S<-matrix(nrow=n1,ncol=dimS) 
  for (i in 1:n1) {
    theta[i,] <- pftn()
    output<- Model_MVN(theta_vals=theta[i, ],n=1000,Sigma_0=Sigma_0)
    
    #Computing the summary stats for each simulation realisation
    S[i, ] <-  Summary_stats(data=output)
    #Saving weighted distances
    d[i] <- distance(Summary_sim=S[i, ],Summary_obs=summaries_obs, weight=w)
  }
  return(list(theta=theta, S=S, d=d))
}


#Weighted-euclidean distance
distance<- function(Summary_sim,Summary_obs,weight){
  dist<- sum(weight*(Summary_sim-Summary_obs)^2)
  return(sqrt(dist))
}

#Multivariate Normal kernel function given optimal bandwidth
#For peturbation
MultivNorm_rkernel<- function(Num,bandwidth_matrix){
  dim_k<- dim(bandwidth_matrix)[2]
  mean_vector<- rep(0,dim_k)
  return(tmvtnorm::rtmvnorm(n=1, mean=mean_vector, sigma=bandwidth_matrix, 
                            lower=rep(-.1,dim_k),upper=rep(.1,dim_k), algorithm=c("gibbs")))
}





#Posterior function (draw from a new proposal distribution)
post <- function(samp=tha_post,importance_weight=weight,optimal_bw_matrix=Sigma_optimal_t) {
  # new proposal from samp (previous prior samples)
  n <- dim(samp)[1]#dimension of proposal samples at t-1
  #randomly sampling from 1:n different sets of parameter values (importance sampling)
  #from previously accepted particles
  sample.particle<-sample(n, 1,prob=importance_weight)
  
  # Perturbation kernel: perturbing the particles for a new proposal  
  KDE_sampler<- samp[sample.particle, ]+MultivNorm_rkernel(Num=1,
                                                           bandwidth_matrix=optimal_bw_matrix) 
  
  new_proposal<- KDE_sampler
  x<- new_proposal
  x[1:6] <- sort(x)
  return(x)
}



na.zero<-function(x){
  x[is.na(x)]<-0
  return(x)
}

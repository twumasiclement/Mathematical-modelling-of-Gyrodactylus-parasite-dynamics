require("kedd")
#Gaussian kernel with bandwidth delta
guass_kernel<- function(dist,delta){
  kern<-  (sqrt(2*pi*delta))* exp(-(dist^2)/(2* delta^2))
  return(kern)
}

Post_Ridge_reg_adj_L2<- function(post_distn,summary_obs,Sigma_0) {
  #k #biasing parameter or ridge regression penalty parameter
  # post_dtn is the posterior sample
  # w are weights across summary statistics for computing weighted distance
  no_of_parameters<- 6
  posterior_mean_adj<- rep(NA,no_of_parameters) #storing adjusted posterior means
  dimS<- length(summary_obs)#dimension of summaries
  #Combining the summary stats for the observed data for the parasite-fish groups
  m<- dim(post_distn)[1]# m=number of posterior samples
  d<- rep(0, m)# weighted distances given observed data
  p<- length(summary_obs) #dimension of summary statistics
  Unadj_dist<- post_distn
  X_Design_matrix<- matrix(NA, ncol=p,nrow=m) #design matrix
  S<-matrix(nrow=m,ncol=dimS) #storing simulated summaries
  # Weights based on Gaussian kernel for local-linear regression adjustment
  W<- matrix(0, ncol=m,nrow=m)
  X_bar=numeric(length=p) #saving weighted column means of design matrix 
  for (i in 1:m) {
    theta<- as.vector(unlist(post_distn[i,]))
    
    output<- Model_MVN(theta_vals=theta,n=1000,Sigma_0=Sigma_0)
    
    #Computing the summary stats for each simulation realisation
    S[i, ] <-  Summary_stats(data=output)
    diff<- S[i, ]-summary_obs
    X_Design_matrix[i, ]<- diff  #storing each row of design matrix X
  }
  
  # Computing weights based on
  #Storing the summary stats and distance (between summaries of observed and simulated data)
  w <-apply(S, 2, var, na.rm = TRUE)
  w<- w/sum(w) #normalised weight for computing distance
  
  for(i in 1:m) d[i] <- distance(Summary_sim=S[i, ],Summary_obs=summary_obs, weight=w)
  
  distances<-d
  #Adaptively choosing the bandwidth of the Gaussian kernel based on the distances
  bandwidth<- kedd::h.amise(x=distances, deriv.order =0,kernel = c("gaussian"))$h
  #bandwidth<- KernSmooth::dpik(x=distances, kernel = "normal",scalest = "minim")
  diag(W)<- guass_kernel(dist= distances,delta=bandwidth)
  theta_post<- as.matrix(post_distn)  
  weights<- diag(W)/sum(diag(W)) # (normalising) main diagonal of Weighting matrix
  
  #Transforming X and Y (posterior distribution and summary statistics)
  for(j in seq_along(posterior_mean_adj)){#For each jth model parameter, j=1,2,...23
    X<- X_Design_matrix
    Y<- theta_post[ ,j]
    
    #Step 1 (Mean centring X and Y)
    for (k in 1:p) X_bar[k]<- sum(weights*X[,k])
    
    for (k in 1:p) {
      X[, k]<- X[, k]-X_bar[k]
    }
    #finding the weighted mean of Y and mean centring
    Y_bar <- sum(weights*Y)
    Y<- Y- Y_bar
    
    
    #Step 2: scaling (centred X and Y) by weights
    
    for(k in 1:p) X[, k]<- sqrt(weights)*X[, k]
    Y<- sqrt(weights)*Y
    
    #Choose optimal value of k (the penalty paramters)
    # Using cross validation glmnet
    # Setting the range of lambda values
    options(warn = -1)
    lambda_seq <- 10^seq(2, -2, by = -.1)
    ridge_cv <- cv.glmnet(X, Y, alpha = 0, lambda =lambda_seq)
    # Best lambda value
    best_lambda <- ridge_cv$lambda.min
    k<-best_lambda
    #print(k)
    
    
    
    # calculating beta estimates of predictors
    beta_ridge <- solve(t(X) %*%W%*%X+ k*diag(p)) %*% t(X)%*%W%*%Y
    
    alpha_estimate<- Y_bar - X_bar%*%beta_ridge
    # calculate intercept estimates (adjusted posterior mean estimates)
    posterior_mean_adj[j] <- exp(alpha_estimate)
    
    #Adjusting the posterior distribution
    Unadj_dist[,j]<- post_distn[, j]- X_Design_matrix%*%beta_ridge
    
  }
  
  
  
  posterior_mean_uadj<-   apply(exp(post_distn),2,mean)

  Posterior_mean_output<- data.frame(Adj_posterior_mean=posterior_mean_adj,
                                     Uadj_posterior_mean=posterior_mean_uadj)

  
  #returns the design data matrix, adjusted & unadjusted
  # means, and the adjusted posterior distribution
  return(list(X_Design_matrix=X,Posterior_mean_output=Posterior_mean_output,Adjusted_posterior_dist=Unadj_dist))
}
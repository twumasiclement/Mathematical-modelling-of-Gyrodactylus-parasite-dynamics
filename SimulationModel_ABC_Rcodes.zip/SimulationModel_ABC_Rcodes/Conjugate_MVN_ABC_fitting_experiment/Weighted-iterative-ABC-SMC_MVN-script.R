Weighted_iterative_ABC_MVN<- function(N=5,dimS=dimS,numCores=numCores,ABC_time_steps=10){
  
  n_cores <- numCores   #Run on  n cores
  n1<- N/n_cores
  number_of_parameters<- 6 #number of parameters to be estimated
  #Storing importance weight for sequential sampling
  import_weights<- NULL
  #Storing weights corresponding to accepted samples
  w_accepted<- NULL
  dim_tha_post<-NULL #saving number of particles for each iteration
  S_i <- NULL #saving saving stats for each simulation realizaton  
  #ABC_time_steps= time for the algorithm to terminate
  eps<-NULL # storage for index of accepted particles
  #proportion of sample to retain during sequential sampling (10 steps)
  if(N<1000){
    epsilon<- c(0.5,0.43,0.4,0.35,0.3,0.2,0.1,0.08,0.06,0.02)
  }else if(N>=1000){
    epsilon<-c(0.5,0.3,0.2,0.1,0.08,0.07,0.06,0.03,0.02,0.01)
  }
  d_i<-NULL;d<-NULL#storing weighted distances between summary stats at time t
  
  #For storing parameter values at time t
  theta_i<- NULL;theta<-NULL
  
  # for density plots (256 used here is 
  #the number of equally spaced points at which the density is to be estimated)
  xmin=-1.5; xmax=1.5
  x <- seq(from = xmin, to = xmax, length.out = 256)#range of prior distribution
  fx <- array(dim=c(ABC_time_steps+1, number_of_parameters, 256))
  
  time0<- proc.time()
  for (t in 1:ABC_time_steps) {
    cat("ABC_time_steps", t, "\n")
    if (t == 1) {
      pftn <- prior
      ABC_out <- mclapply(1:n_cores, ABC, pftn=pftn, n1=n1, w=w, mc.cores=n_cores)
      for (i in 1:n_cores) {
        theta_i[[i]] <- ABC_out[[i]]$theta
        S_i[[i]] <- ABC_out[[i]]$S
        d_i[[i]] <- ABC_out[[i]]$d 
      }
    }
    ##################################################################################### 
    
    else{#if t>1
      #Calculating optimal value of the variance
      #N0= number of accepted particles
      #N1= total number of proposal samples
      #eps[[t]]= index of accepted samples
      #w_accepted[[t]]= weights corresponding to accepted particles
      #tha_post= accepted proposals at time t
      
      #Optimal bandwith matrix for multivariate normal perturbation kernel
      #Sigma_optimal_t=Optimal bandwith matrix
      # using the Kullback--Leibler divergence minimisation approach
      Sigma_optimal_t<- matrix(0,nrow=number_of_parameters,ncol=number_of_parameters)
      
      N1<-dim(theta[[t-1]])[1]
      N0<- dim(tha_post)[1]
      for(i in 1:N1) {
        for(k in 1:N0){
          Sigma_optimal_t<- Sigma_optimal_t+(import_weights[[t-1]][i]*w_accepted[[t-1]][k]*  
                                  (matrix(tha_post[k,]-theta[[t-1]][i, ])%*%t(matrix(tha_post[k,]-theta[[t-1]][i, ]))))
        }     
      }  
      
      
      ##Sampling from the Multivariate Normal Perturbation kernel
      weight<-w_accepted[[t-1]]
      pftn <- function() post(tha_post,weight,Sigma_optimal_t)
      
      ABC_out <- mclapply(1:n_cores, ABC, pftn=pftn, n1=n1, w=w, mc.cores=n_cores)
      for (i in 1:n_cores) {
        theta_i[[i]] <- ABC_out[[i]]$theta
        S_i[[i]] <- ABC_out[[i]]$S
        d_i[[i]] <- ABC_out[[i]]$d 
      }
      #Combining theta at time t
      theta[[t]]<- na.omit(do.call("rbind",theta_i))# N by 42 matrix
      
      #Re-weighting for importance sampling
      
      import_weights[[t]]<-rep(NA,length=N)
      
      #Evaluating the perturbation kernel for each particle at time t
      K_normal_kernel<-NULL
      for(i in 1:dim(theta[[t]])[1]){
        K_normal_kernel[[i]]<- mvtnorm::dmvnorm(x=theta[[t]][i, ], 
                                      mean = theta[[t-1]][i, ],sigma =Sigma_optimal_t)
      }
      
      
      #### KDE of proposal probability distribution####
      #Estimating the optimal bandwidth
      density_proposals<- matrix(NA, nrow=length(import_weights[[t]]),ncol=number_of_parameters)
      N1<-length(unlist(K_normal_kernel))
      for(i in seq_along(import_weights[[t]])){
        
        density_proposals[i, ]<- ks::kde(x = theta[[t]][i, ],
                                         eval.points = theta[[t]][i, ])$estimate
        #KDE value for each proposal sample
        par.weight.numerator<-   mean(density_proposals[i, ])
        par.weight.denominator<- sum(import_weights[[t-1]][1:N1]*unlist(K_normal_kernel))
        import_weights[[t]][i]<- par.weight.numerator/par.weight.denominator                               
      }
      
      #normalizing weights
      import_weights[[t]]<- import_weights[[t]]/sum(import_weights[[t]]) 
      
      
    }
    
    ##################################################################################   
    
    #Combining results from the ncores
    theta[[t]]<- na.omit(do.call("rbind",theta_i))# N by 23 matrix
    
    d[[t]]<- na.omit(do.call("c",d_i)) #length of N
    #print(d[[t]])
    small_draws<- epsilon[t]*N #number of draw for posterior samples
    theta_dist<- cbind(theta[[t]],d[[t]])#adding the computed distance as extra column of theta matrix
    eps[[t]]<- order(theta_dist[,7])[1:small_draws]#smallest distance index 
    
    
    # choose posterior samples
    tha_post<-theta_dist[eps[[t]],][ ,-7]
    
    
    dim_tha_post[[t]]<- dim(tha_post)[1]
    #initialize importance weight for sequential sampling
    if(t==1)  import_weights[[1]]<- rep(1/N,length=N)
    
    #Weights corresponding to accepted proposal samples
    w_accepted[[t]]<- import_weights[[t]][eps[[t]]]
    w_accepted[[t]]<- w_accepted[[t]]/sum(w_accepted[[t]])#normalising accepted weights
    
    # update summary statistics weights (different from importance sampling weights) for weighted 
    #sum of squares distance between S_sim and S_obs (summary statistics)
    eps_dist_max <- sort(d[[t]])[small_draws]#max least distance
    S<-na.omit(do.call("rbind",S_i))#combining the summary stats [(N*fish_total) by 17 matrix]
    
    w1inv <-  apply(S[d[[t]]<=eps_dist_max , ], 2, var, na.rm = TRUE)
    w <- na.zero(2/(1/w + w1inv))
    
    
    # densities
    if (t == 1) {
      for (k in 1:number_of_parameters) { 
        fx[1,k,] <- density(theta[[1]][ ,k], from =  xmin, to =   xmax, n=256)$y
        #saving the densities for each iteration
        write.csv(fx[1, ,], file = paste0("density_post_", 1,"_",N, ".csv"))
      }
    }
    for (k in 1:number_of_parameters) {
      fx[t+1,k,] <- density(tha_post[, k], from =  xmin, to =  xmax, n=256)$y
      
      #saving the densities for each iteration
      write.csv(fx[t+1, ,], file = paste0("density_post_", t+1,"_",N,".csv"))
      
    }
    #saving importance weights 
    #write.csv(import_weights[[t]], file = paste0("importance_weights_",t,"_",N,".csv")) 
    
    #accepted particles at each iteration
    #write.csv(tha_post, file = paste0("theta_post_", t,"_",N, ".csv"))
    
    #saving weighted distance
    #write.csv(d[[t]],file = paste0("weighted_distance_", t, "_",N,".csv"))
  }
  
  timef<- proc.time()-time0
  CPUtime<-sum(as.vector(timef)[-3])
  write.csv(CPUtime,file=paste0("CPUtime_", N, ".csv"))
  
  return(list(fx=fx,final_posterior=tha_post,theta0=theta[[1]]))
} #end of the weighted-iterative ABC algorithm



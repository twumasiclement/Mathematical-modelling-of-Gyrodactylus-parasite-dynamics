#Loading packages
library(see)
library(transport) #For Wassertein distance computation
library(parallel) # For parallizing R codes
RNGkind("L'Ecuyer-CMRG") #Dealing with distinct seed value in R
#library(markovchain)
#library(diagram)
library('latex2exp') #For adding LaTeX symbols to R plots
library(compiler)# byte code compilation
library(data.table)
library("maxLik")#for maximum likelihood estimation/optimization
library("R.utils")
library(MASS)
library("kader")
library("PerformanceAnalytics")
library(glmnet)
library("kedd")
library(bayestestR)#for credible interval and HDI+ROPE decision
#library("sjstats")#for HDI+ROPE decision
#library(sjmisc)
#library(rstanarm)
#library("HDInterval")
#library("LaplacesDemon")

#set working directory 
#setwd(paste0("/home/clement/Documents/Regression_adjust_SimulationModel_new"))
setwd("C:/Users/user/Desktop/DataAnalysis_results_R/ABC_SMC_Simulation_main/Modified ABC-SMC fitting_results_current/Regression_adjustment_new/Regression_adjust_SimulationModel_new/Regression_adjust_SimulationModel_new")

#Importing posterior densities from Weighted-iterative ABC with Sequential Monte Carlo with importance sampling
draws<- c(500)
density_post<-NULL

for(n in draws){ 
    
ABC_iterations<-11
number_of_parameters<- 23
x <- seq(from = -10, to = 7, length.out = 256)#range of prior distribution
density_post[[n]]<- list()
for(j in 1:ABC_iterations) {
    density_post[[n]][[j]]<-read.csv(file=paste0("density_post_",j,"_",n,".csv"))
    density_post[[n]][[j]]<-density_post[[n]][[j]][,-1]
          }
}

#Importing posterior densities from Weighted-iterative ABC with Sequential Monte Carlo with importance sampling
draws<- c(500)
density_post<-NULL

for(n in draws){ 
    
ABC_iterations<-11
number_of_parameters<- 23
x <- seq(from = -10, to = 7, length.out = 256)#range of prior distribution
density_post[[n]]<- list()
for(j in 1:ABC_iterations) {
    density_post[[n]][[j]]<-read.csv(file=paste0("density_post_",j,"_",n,".csv"))
    density_post[[n]][[j]]<-density_post[[n]][[j]][,-1]
          }
}

parameter_labels=c(expression(paste("b"[11])),expression(paste("b"[12])),
                   expression(paste("b"[21])),expression(paste("b"[22])), 
                   expression(paste("b"[31])),expression(paste("b"[32])),
                   expression(paste("d"[11])),expression(paste("d"[12])),
                   expression(paste("d"[21])),expression(paste("d"[22])), 
                   expression(paste("d"[31])),expression(paste("d"[32])),
                   expression(paste("m")),  expression(paste("r")),
                   expression(paste("r"[1])),expression(paste("r"[2])),
                   expression(paste("r"[3])),expression(paste("s")),
                   expression(paste("s"[1])),expression(paste(epsilon[1])),
                   expression(paste(epsilon[2])),expression(paste(epsilon[3])),
                   expression(paste(kappa)))
options(repr.plot.width=8, repr.plot.height=8,repr.plot.res = 300) #Setting plot size

data.frame(1:23,paste(parameter_labels))


#All model parameters
n<-500
#par(mfrow=c(5,5), mar=c(4,0,1,0),font=2)
par(mfrow=c(5,5), mar=c(4,2,1,0),font=2)
plot(NULL ,xaxt='n',yaxt='n',bty='n', xlab="", ylab="",xlim=0:1, ylim=0:1)
plot_colors <- c("blue","red","black")
legend(x=-0.1,y=1.2,c(paste0("First Prior 
(N=",n,")"),"Intermediate 
Priors" ,"Final Posterior"),
        col=c("blue","red","black"),bty="n",cex=1.05,box.lwd = .8,fill=c("blue","red","black"),horiz=F)


for (k in 1:23) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
  
    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1,ann=FALSE,yaxt="n")
   
}






#### External scripts for the simulation model and ABC #####

#Script of function for computing event rates
source("Computing-rates-script.r")

# Script of function for updating exact SSA
source("Update-exactSSA-script.r")

# Script of function for updating tau-leaping
source("Update-tauleaping-script.r")

# Script of function experimental descriptors 
# (fish type, strain, fish size, fish sex and areas of the 4 body regions)
source("Descriptors-Data-script.r")

# Script of function for simulating parasites only a single fish over time and across body regions
source("Simulation-single-fish-script.r")

# Script of function for simulating parasites for a group fish over time and across body regions
#Corresponding to the empirical data
source("Simulation-Group-fish-script.r")

#Script of functions for Galton-Watson & GMM estimation of the B-D-C parameters
source("MLE_catastrophe-script.r")
source("GMM-1st2nd-Steps-script.r")
source("BDC-GW-GMM-estimator-script.r")

#Script for population projection until day 17 after fish death to aid with ABC fitting
source("Project-Parasite-script.r")

#Script for function used to compute the 17 summary statistics for ABC fitting:
#1.Log count across time (9)
#2.Wasserstein distance between the four body regions (4),
#3.Estimates of the B-D-C model parameters (3)
#4.Time before death (1)
source("summary-stats-ABC-script.r")


#Function for posterior adjustment using Weighted Ridge Regression

source("Post-Beaumount-LogLinear-script.R")
source("Post-Ridge-reg-adj-L2-script.R")

#To detect the number of processors or cores of your computer 
numCores<-min(16,detectCores())
numCores

#Importing empirical data 
Combined_data <- read.csv(file="Parasite_Data.csv") 
#Importing data for area of the 8 body parts across 18 fish (measured in millimeters square)
Bodyparts_area<-read.csv(file="Area_Fish_bodyParts.csv")

#Experimental descriptors
Descriptors<- Experiment_descriptors(empirical_data=Combined_data)

fishSize <- Descriptors$fishSize #fish size
fishSex  <- Descriptors$fishSex #fish sex
Strain   <- Descriptors$Strain # parasite strain
Fish_stock<-Descriptors$Fish_stock #fish stock
numF    <-  Descriptors$numF # total fish for each parasite-fish group 
fishID  <-  Descriptors$fishID # fish IDs for each parasite-fish group 
pop_obs <-  Descriptors$pop_obs # observed parasite numbers for each parasite-fish group 
alive_obs<- Descriptors$alive_obs # observed surviva status for each parasite-fish group 
Area_normalized<- Body_area(Area_data=Bodyparts_area)#body areas

#Parasite-fish groups
parasite_fish<-c("Gt3-OS","Gt3-LA","Gt3-UA","Gt-OS","Gt-LA","Gt-UA","Gb-OS","Gb-LA","Gb-UA") 

#B-D-C parameter estimates for the parasite-fish groups based on observed data
BDC_estimates_obs<- GW_GMM_BDCestimator(X0=2,pop=pop_obs,alive=alive_obs,
                                        group=parasite_fish)$BDC_estimates
BDC_estimates_obs

#View ABC summary statistics for the observed data
summaries_obs[[1]]# for group 1 or Gt3-0S group

#Importing final posterior at different sample sizes of initial prior distn
Final_posterior<-NULL
draws<- c(500)
for (n in draws){
  Final_posterior[[n]]<- read.csv(paste0("PosteriorFinal_", n, ".csv"))
  Final_posterior[[n]]<-Final_posterior[[n]][,-1]
  #print(paste("draws=",n))
  #print(Final_posterior[[n]])
}

#Estimating the 95% Credible interval for the unadjusted posterior
ci_eti<- NULL;Posterior_estimates_unadj<- NULL

for(n in draws){
  #computing credible intervals (ETI)
  post_data<-   Final_posterior[[n]]
  ci_eti[[n]]<- ci(as.data.frame(post_data), ci = 0.95,method = "ETI") 
  ci_eti[[n]]<- exp(as.data.frame(ci_eti[[n]][,3:4]))
   # estimating the  posterior  mean estimate
  Posterior_estimates_unadj[[n]]<- apply(exp(Final_posterior[[n]]),2,mean)
    }

Posterior_est_unadj_data<- data.frame(Posterior_estimate_unadj=Posterior_estimates_unadj[[500]],
                                     Cred_Int_lower95_unadj= ci_eti[[500]][,1],
                                     Cred_Int_upper95_unadj= ci_eti[[500]][,2])

#Print unadjusted posterior estimates with 95% credible intervals
Posterior_est_unadj_data

w_distance <- function(S1, S2, weight)  {
  n<- dim(S1)[1]
  Squared_diff_mat<- (S1-S2)^2 #squared difference between matrix S1 & S2
  #Multiplying vector to weights to each rows of  Squared_diff_mat
  Weighted_sq_diff<- lapply(1:dim(S1)[1],
              function(k) weight*Squared_diff_mat[k, ])
  WSS<- do.call("sum",Weighted_sq_diff)#total weighted distances (WSS)
  return(sqrt(WSS/n))#return weighted sum of square distance 
}

#Observed summary statistics across all observed fish
SummaryStats_obs_combined<- do.call("rbind", summaries_obs)

#Initial simulation inputs for A (parasite numbers) and  B (immune status)
A0 <- matrix(0, 4, 2)  
A0[1, 1] <- 2   #Intial parasites at the tail
B0 <- rep(1, 4)  #initial immune response at 4 body regions (no response)

#Transition matrix
J<- matrix(c(0,    1,    0,     0, 
             1/2,   0,    1/2,   0,
             0,    1/2,    0,   1/2,
             0,     0,     1,    0), 4, 4, byrow=TRUE)
        

na.inf.zero<- function(x){
    x[is.na(x)|is.finite(x)==FALSE]<- 0
    return(x)
}


Reg_adjust_L2<- function(i) Post_Ridge_reg_adj(post_distn=Final_posterior[[draws[i]]],
                                    summary_obs= SummaryStats_obs_combined)

Output_adj_L2<- mclapply(seq_along(draws),Reg_adjust_L2,mc.cores=1)

#Adjustment of Posterior at N=500 based on Proposed regression adjustment
#Output_adj_L2[[1]]$Posterior_mean_output


print(paste("Proposed adjusted posterior estimates at N=",draws[1]))
Output_adj_L2[[1]]$Posterior_mean_output[,1]

print(paste("ABC posterior estimates at N=",draws[1]))
Output_adj_L2[[1]]$Posterior_mean_output[,2]


#Saving output
for(i in seq_along(draws)) {
    write.csv(Output_adj_L2[[i]]$Posterior_mean_output,
                        paste0("Posterior_mean_adjustment_L2_",draws[i],".csv"))

    write.csv(Output_adj_L2[[i]]$Adjusted_posterior_dist,
                        paste0("Posterior_adjusted_distn_L2_",draws[i],".csv"))

               }

library("corrplot")

i=1
M<-cor(Output_adj_L2[[i]]$X_Design_matrix)
head(round(M,2))


# mat : is a matrix of data
# ... : further arguments to pass to the native R cor.test function
cor.mtest <- function(mat, ...) {
    mat <- as.matrix(mat)
    n <- ncol(mat)
    p.mat<- matrix(NA, n, n)
    diag(p.mat) <- 0
    for (i in 1:(n - 1)) {
        for (j in (i + 1):n) {
            tmp <- cor.test(mat[, i], mat[, j], ...)
            p.mat[i, j] <- p.mat[j, i] <- tmp$p.value
        }
    }
  colnames(p.mat) <- rownames(p.mat) <- colnames(mat)
  p.mat
}
# matrix of the p-value of the correlation
i=1
p.mat <- cor.mtest(Output_adj_L2[[i]]$X_Design_matrix)
head(p.mat[, 1:5])



?chart.Correlation

X_matrix<- as.data.frame(Output_adj_L2[[1]]$X_Design_matrix)

for (i in 1:dim(X_matrix)[2]) names(X_matrix)[i]<- paste0("S_",i)

chart.Correlation(X_matrix, histogram=TRUE, pch=19)

#corrplot(M, method="number",type="lower", order="hclust")

#Adjustment of Posterior at N=500 based on Proposed regression adjustment
Reg_adjust_Beaumont<- function(i) Post_Beaumont_reg_adj(post_distn=Final_posterior[[draws[i]]],
                                    summary_obs= SummaryStats_obs_combined)

Output_adj_Beaumont<- mclapply(seq_along(draws),Reg_adjust_Beaumont,mc.cores=numCores)

#Importing final posterior at different sample sizes of initial prior distn
Adjusted_posterior<-NULL
draws<- c(500)
for (n in draws){
  Adjusted_posterior[[n]]<- Output_adj_L2[[1]]$Adjusted_posterior_dist
}

#Estimating the 95% Credible interval for the unadjusted posterior
ci_eti_adj<- NULL;Posterior_estimates_adj<- NULL

  #computing credible intervals (ETI)
  post_data<-  Adjusted_posterior[[n]]
  ci_eti_adj[[n]]<- ci(as.data.frame(post_data), ci = 0.95,method = "ETI") 
  ci_eti_adj[[n]]<- exp(ci_eti_adj[[n]][,3:4])
   # estimating the  posterior  mean estimate
  Posterior_estimates_adj[[n]]<- Output_adj_L2[[1]]$Posterior_mean_output[,1]
    

Posterior_est_adj_data<- data.frame(Posterior_estimate_adj=Posterior_estimates_adj[[500]],
                                     Cred_Int_lower95_adj= ci_eti_adj[[500]][,1],
                                     Cred_Int_upper95_adj= ci_eti_adj[[500]][,2])

#Print unadjusted posterior estimates with 95% credible intervals
Combined_posterior_adj_unadj<- cbind(Posterior_est_adj_data,Posterior_est_unadj_data)
Combined_posterior_adj_unadj

#Save output
write.csv(Combined_posterior_adj_unadj,"Post_Regression_output.csv")

time_CPU<- NULL
for(n in draws) {
    time_CPU[[n]]<- read.csv(file=paste0("CPUtime_",n,".csv"))
    time_CPU[[n]]<- time_CPU[[n]][,-1]
    }

#Computational times
 for(i in seq_along(draws))  print(paste("CPU time at N=", draws[i],"",":",time_CPU[[draws[i]]]/10,"secs"))

 for(i in seq_along(draws))  print(paste("CPU time at N=", draws[i],"",":",time_CPU[[draws[i]]]/864000,"days"))

#Converting from seconds to days
  library(lubridate)
 for(i in seq_along(draws))  print(paste("CPU time at N=", draws[i],"",":",seconds_to_period(time_CPU[[draws[i]]]/10)))
options(warn=-1)

require(plotrix)

#Adjusted posterior
x <- 1:23
F <- log(Combined_posterior_adj_unadj[,1])
L <-  log(Combined_posterior_adj_unadj[,2])
U <-  log(Combined_posterior_adj_unadj[,3])
plotCI(x, F, ui=U, li=L,xaxt="n",xlab="Model parameters",
       ylab="Posterior mean with 95% credible interval (log scale)",
       col="blue",lwd=1.5,ylim=c(-10,5),xaxt="n",pch=20
      ,las=1)

 axis(1, at=1:23, labels=parameter_labels)
legend(x=6,y=5.8,c("Adjusted","Unadjusted"),
        col=c("blue","red"),bty="n",cex=1.05,box.lwd = .8,fill=c("blue","red"),horiz=F,
      title="Posterior distribution")


#Unadjusted posterior
x <- 1:23
F <- log(Combined_posterior_adj_unadj[,4])
L <-  log(Combined_posterior_adj_unadj[,5])
U <-  log(Combined_posterior_adj_unadj[,6])
plotCI(x, F, ui=U, li=L,col="red", add=TRUE,lwd=1,pch=20)


#Estimating the kernel density of the adjusted posterior

density_post_adjusted<- array(dim=c(number_of_parameters, 256))

for(k in 1:number_of_parameters){
density_post_adjusted[k, ]<- density(Output_adj_L2[[1]]$Adjusted_posterior_dist[ ,k], from=-10, to=7, n=256)$y
}



par(mfrow=c(3,2),mar=c(4,4,1,1))
n=500
x <- seq(from = -10, to = 7, length.out = 256)#range of prior distribution

for (k in 1:6) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="Density", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
  
    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1)
     lines(x,density_post_adjusted[k, ], col="green",lty=3,lwd=2)
    legend("topleft",c("First Prior","Intermediate Priors" ,"Unadjusted Posterior","Adjusted Posterior"),
         col=c("blue","red","black","green"),bty="n",cex=1,box.lwd = 2,fill=c("blue","red","black","green"))
    }
   

n=500
par(mfrow=c(3,2),mar=c(4,4,1,1))
for (k in 7:12) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="Density", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
  
    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1)
     lines(x,density_post_adjusted[k, ], col="green",lty=3,lwd=2)
    legend("topleft",c("First Prior","Intermediate Priors" ,"Unadjusted Posterior","Adjusted Posterior"),
         col=c("blue","red","black","green"),bty="n",cex=1,box.lwd = 2,fill=c("blue","red","black","green"))
    }
   

n=500
par(mfrow=c(3,2),mar=c(4,4,1,1))
for (k in 13:18) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="Density", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
  
    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1)
     lines(x,density_post_adjusted[k, ], col="green",lty=3,lwd=2)
    legend("topleft",c("First Prior","Intermediate Priors" ,"Unadjusted Posterior","Adjusted Posterior"),
         col=c("blue","red","black","green"),bty="n",cex=1,box.lwd = 2,fill=c("blue","red","black","green"))
    }
   

n=500
par(mfrow=c(3,2),mar=c(4,4,1,1))
for (k in 19:23) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="Density", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
  
    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1)
     lines(x,density_post_adjusted[k, ], col="green",lty=3,lwd=2)
    legend("topleft",c("First Prior","Intermediate Priors" ,"Unadjusted Posterior","Adjusted Posterior"),
         col=c("blue","red","black","green"),bty="n",cex=1,box.lwd = 2,fill=c("blue","red","black","green"))
    }
   

setwd("C:/Users/user/Desktop/DataAnalysis_results_R/ABC_SMC_Simulation_main/Modified ABC-SMC fitting_results_current/Regression_adjustment_new")

#Importing adjusted posterior distribution (on log scale)
Posterior_distn_adj500<- read.csv(file="Posterior_adjusted_distn_L2_500.csv")
Posterior_distn_adj500<- Posterior_distn_adj500[,-1]
#Inverse scaling
Posterior_distn_adj500<- exp(Posterior_distn_adj500)

# Function to perform Region of Practical Equivalence (ROPE) and Highest Density Interval (HDI)
require(bayestestR)
ROPE_Cred_Int<- function(theta_distn_diff,parameter_labels, ci_percent=0.89){
    if(is.list(theta_distn_diff)==FALSE){
        sigma_d<- sd(theta_distn_diff)#standard deviation of differenced posterior samples
        output<- bayestestR::equivalence_test(theta_distn_diff, 
                #ROPE range is based on recommendation by Norman et al (2003)
                range =c(-.5*sigma_d,.5*sigma_d), ci = ci_percent,ci_method = "HDI")
    final_output<- cbind(parameter_labels,output);names(final_output)[1]<- "Parameter"
    return(final_output)
    }
    #theta_distn_diff= a list of posterior samples of differences of parameters of interest
    output<-list() #save ROPE+HDI results
    for(i in seq_along(parameter_labels)){
     sigma_d<- sd(theta_distn_diff[[i]])#standard deviation of differenced posterior samples
    output[[i]]<- bayestestR::equivalence_test(theta_distn_diff[[i]], 
                #ROPE range is based on recommendation by Norman et al (2003)
                range =c(-.5*sigma_d,.5*sigma_d), ci = ci_percent,ci_method = "HDI")
        }
    
     #Function returns ROPE interval, ROPE Percentage, ROPE equivalence decision
      # and the corresponding HDI 
    final_output<- do.call("rbind",output)
    final_output<- cbind(parameter_labels,final_output)
    names(final_output)[1]<- "Parameters"
    return(final_output)
} 

#Extracting corresponding adjusted posterior samples
b1_young_posterior<- Posterior_distn_adj500[, c(1,3,5)]
b1_young_diff<- NULL

parameter_labels<- c("b_11-b_21","b_11-b_31","b_21-b_31")
dim<- length(parameter_labels)


g<-0#initialise number of groups
for(i in 1:(dim-1)){
    for(j in (dim-1):dim){
        if(i!=j){
            print(paste("i=",i,"","j=",j))
            g<- g+1
            #Compute posterior of the difference under H0
            b1_young_diff[[g]]<-b1_young_posterior[,i]-b1_young_posterior[,j]
        }
    }
      
 }       
 
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=b1_young_diff,parameter_labels=parameter_labels, ci_percent=0.89)
       

#Extracting corresponding adjusted posterior samples
b2_old_posterior<- Posterior_distn_adj500[, c(2,4,6)]
b2_old_diff<- NULL

parameter_labels<- c("b_12-b_22","b_12-b_32","b_22-b_32")
dim<- length(parameter_labels)


g<-0#initialise number of groups
for(i in 1:(dim-1)){
    for(j in (dim-1):dim){
        if(i!=j){
            print(paste("i=",i,"","j=",j))
            g<- g+1
            #Compute posterior of the difference under H0
            b2_old_diff[[g]]<-b2_old_posterior[,i]-b2_old_posterior[,j]
        }
    }
      
 }       
 
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=b2_old_diff,parameter_labels=parameter_labels, ci_percent=0.89)


#Extracting corresponding adjusted posterior samples
b_posterior<- Posterior_distn_adj500[, 1:6]
b_diff<- NULL

parameter_labels<- c("b_11-b_12","b_21-b_22","b_31-b_32")
#Compute posterior of the difference under H0
b_diff[[1]]<- b_posterior[,1]-b_posterior[,2]
b_diff[[2]]<- b_posterior[,3]-b_posterior[,4]
b_diff[[3]]<- b_posterior[,5]-b_posterior[,6]
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=b_diff,parameter_labels=parameter_labels, ci_percent=0.89)


#Extracting corresponding adjusted posterior samples
d_nr_posterior<- Posterior_distn_adj500[, c(7,9,11)]
d_nr_diff<- NULL

parameter_labels<- c("d_11-d_21","d_11-d_31","d_21-d_31")
dim<- length(parameter_labels)


g<-0#initialise number of groups
for(i in 1:(dim-1)){
    for(j in (dim-1):dim){
        if(i!=j){
            print(paste("i=",i,"","j=",j))
            g<- g+1
            #Compute posterior of the difference under H0
            d_nr_diff[[g]]<-d_nr_posterior[,i]-d_nr_posterior[,j]
        }
    }
      
 }       
 
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=d_nr_diff,parameter_labels=parameter_labels, ci_percent=0.89)
       

#Extracting corresponding adjusted posterior samples
d_r_posterior<- Posterior_distn_adj500[, c(8,10,12)]
d_r_diff<- NULL

parameter_labels<- c("d_12-d_22","d_12-d_32","d_22-d_32")
dim<- length(parameter_labels)


g<-0#initialise number of groups
for(i in 1:(dim-1)){
    for(j in (dim-1):dim){
        if(i!=j){
            print(paste("i=",i,"","j=",j))
            g<- g+1
            #Compute posterior of the difference under H0
            d_r_diff[[g]]<-d_r_posterior[,i]-d_r_posterior[,j]
        }
    }
      
 }       
 
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=d_r_diff,parameter_labels=parameter_labels, ci_percent=0.89)


#Extracting corresponding adjusted posterior samples
d_posterior<- Posterior_distn_adj500[, 7:12]
d_diff<- NULL

parameter_labels<- c("d_11-d_12","d_21-d_22","d_31-d_32")
#Compute posterior of the difference under H0
d_diff[[1]]<- d_posterior[,1]-d_posterior[,2]
d_diff[[2]]<- d_posterior[,3]-d_posterior[,4]
d_diff[[3]]<- d_posterior[,5]-d_posterior[,6]
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=d_diff,parameter_labels=parameter_labels, ci_percent=0.89)


#Extracting corresponding adjusted posterior samples
e_posterior<- Posterior_distn_adj500[, c(20,21,22)]
e_diff<- NULL

parameter_labels<-c("epsilon_1-epsilon_2","epsilon_1-epsilon_3","epsilon_2-epsilon_3")
dim<- length(parameter_labels)


g<-0#initialise number of groups
for(i in 1:(dim-1)){
    for(j in (dim-1):dim){
        if(i!=j){
            print(paste("i=",i,"","j=",j))
            g<- g+1
            #Compute posterior of the difference under H0
            e_diff[[g]]<-e_posterior[,i]-e_posterior[,j]
        }
    }
      
 }       
 
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=e_diff,parameter_labels=parameter_labels, ci_percent=0.89)


#Extracting corresponding adjusted posterior samples
r_posterior<- Posterior_distn_adj500[, c(15,16,17)]
r_diff<- NULL

parameter_labels<-c("r_1-r_2","r_1-r_3","r_2-r_3")
dim<- length(parameter_labels)


g<-0#initialise number of groups
for(i in 1:(dim-1)){
    for(j in (dim-1):dim){
        if(i!=j){
            print(paste("i=",i,"","j=",j))
            g<- g+1
            #Compute posterior of the difference under H0
            r_diff[[g]]<-r_posterior[,i]-r_posterior[,j]
        }
    }
      
 }       
 
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=r_diff,parameter_labels=parameter_labels, ci_percent=0.89)


s1_posterior<- Posterior_distn_adj500[, 19]

parameter_labels<-c("s_1")
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=s1_posterior,parameter_labels=parameter_labels, ci_percent=0.89)


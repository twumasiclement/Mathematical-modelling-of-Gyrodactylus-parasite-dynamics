
#Loading packages
#Loading packages
library(transport) #For Wasserstein distance computation
library(parallel) # For parallizing R codes
RNGkind("L'Ecuyer-CMRG") #Dealing with distinct seed value in R
#library(markovchain)
#library(diagram)
#library('latex2exp') #For adding LaTeX symbols to R plots
library(compiler)# byte code compilation
#library(data.table)
library("maxLik")#for maximum likelihood estimation/optimization
library("R.utils")
library("KernSmooth")
library("ks")
library(kedd)
library("mvtnorm")
library(Rcpp)# for C+ matrix multiplication
library(tmvtnorm)
#options(repr.plot.width=8, repr.plot.height=8,repr.plot.res = 300) #Setting plot size

#Setting working directory
setwd("/home/clement/Clement_R_Results_folder/Updated_ABC_GOF")

#### External scripts for the simulation model and ABC #####

#Script of function for computing event rates
source("Computing-rates-script.r")

# Script of function for updating exact SSA
source("Update-exactSSA-script.r")

# Script of function for updating tau-leaping
source("Update-tauleaping-script.r")

# Script of function experimental descriptors 
# (fish type, strain, fish size, fish sex and areas of the 4 body regions)
source("Descriptors-Data-script.r")

# Script of function for simulating parasites only a single fish over time and across body regions
source("Simulation-single-fish-script.r")

# Script of function for simulating parasites for a group fish over time and across body regions
#Corresponding to the empirical data
source("Simulation-Group-fish-script.r")

#Script of functions for Galton-Watson & GMM estimation of the B-D-C parameters
source("MLE_catastrophe-script.r")
source("GMM-1st2nd-Steps-script.r")
source("BDC-GW-GMM-estimator-script.r")

#Script for population projection until day 17 after fish death to aid with ABC fitting
source("Project-Parasite-script.r")

#Script for computing weighted distance between summary statistics
source("Weighted-distance-script.R")

#Script for function used to compute the 17 summary statistics for ABC fitting:
#1.Log count across time (9)
#2.Wasserstein distance between the four body regions (4),
#3.Estimates of the B-D-C model parameters (3)
#4.Time before death (1)
source("summary-stats-ABC-script.r")

#Script of function for combining the 17 summary statistics
source("combine-summary-stats-script.R")

#Script wich contains functions of priors, ABC importance sampling
# and Function for ABC fitting
source("ABC-Importance-Sampling-Improved-script.R")

#Script for the Weighted-iterative ABC (with ABC-SMC and adaptive importance sampling)
source("Weighted-iterative-ABC-script.R")

#Export a C+ script which is fast for matrix multiplication
sourceCpp("Fast_Multiplication.cpp")

#To detect the number of processors or cores of your computer 
numCores<-20+2
numCores

#Importing empirical data 
Combined_data <- read.csv(file="Parasite_Data.csv") 
#Importing data for area of the 8 body parts across 18 fish (measured in millimeters square)
Bodyparts_area<-read.csv(file="Area_Fish_bodyParts.csv")

#Experimental descriptors
Descriptors<- Experiment_descriptors(empirical_data=Combined_data)

fishSize <- Descriptors$fishSize #fish size
fishSex  <- Descriptors$fishSex #fish sex
Strain   <- Descriptors$Strain # parasite strain
Fish_stock<-Descriptors$Fish_stock #fish stock
numF    <-  Descriptors$numF # total fish for each parasite-fish group 
fishID  <-  Descriptors$fishID # fish IDs for each parasite-fish group 
pop_obs <-  Descriptors$pop_obs # observed parasite numbers for each parasite-fish group 
alive_obs<- Descriptors$alive_obs # observed surviva status for each parasite-fish group 
Area_normalized<- Body_area(Area_data=Bodyparts_area)#body areas

#Parasite-fish groups
parasite_fish<-c("Gt3-OS","Gt3-LA","Gt3-UA","Gt-OS","Gt-LA","Gt-UA","Gb-OS","Gb-LA","Gb-UA") 


#### Simulate a pseudo-observed data using the Adjusted posterior estimates ####
#Specific parameter values to test the simulation algorithms


Posterior_estimate<- read.csv(file="Posterior_mean_adjustment_L2_500.csv")
Posterior_estimates<- Posterior_estimate$Adj_posterior_mean
print(paste("Adjusted posterior estimates"))
print(Posterior_estimates)

Posterior_estimates_log<-log(Posterior_estimates)




#Initial simulation inputs for A (parasite numbers) and  B (immune status)
A0 <- matrix(0, 4, 2)  
A0[1, 1] <- 2   #Intial parasites at the tail
B0 <- rep(1, 4)  #initial immune response at 4 body regions (no response)

#Transition matrix
J<- matrix(c(0,    1,    0,     0, 
             1/2,   0,    1/2,   0,
             0,    1/2,    0,   1/2,
             0,     0,     1,    0), 4, 4, byrow=TRUE)


#Simulating pseudo observed data based on the fix parameter values for 
#Goodness-of-fit assessment
pop_pseudo_obs<- SimGroup_tauleap(theta1=Posterior_estimates_log,
                          fish_sex=fishSex,fish_type=Fish_stock,strain=Strain,
                          fish_size=fishSize,error=0.01)$pop_sim


#B-D-C parameter estimates for the parasite-fish groups based on observed data
BDC_estimates_obs<- GW_GMM_BDCestimator(X0=2,pop=pop_pseudo_obs,alive=alive_obs,
                                        group=parasite_fish)$BDC_estimates
BDC_estimates_obs



#Computing summary statistics for pseudo-observed data across the parasite-fish groups
summaries_obs<-Summary_stats(pop=pop_pseudo_obs,alive=alive_obs,BDC_estimates=BDC_estimates_obs)


#View ABC summary statistics for the pseudo-observed data
print(paste("Observed summaries of pseudo-observed data for Group 1"))
summaries_obs[[1]]# for group 1 or Gt3-0S group



w=read.csv(file="w0.csv")
w<-as.vector(w[,-1])
w


na.zero<-function(x){
  x[is.na(x)]<-0
  return(x)
}


Total_fish<- dim(do.call("rbind",summaries_obs))[1]


## Conduct ABC fitting based on the pseudo-observed data for 5 times at N=500

ABC_output<- NULL
iterations<- 5
N=500
for (k in 1:iterations){
  print(paste("Goodness-of-fit_iteration=",k))
ABC_output[[k]]<- Weighted_iterative_ABC(N=N,dimS=17,fish_total=Total_fish,
                                    sigma.hyper=1,numCores=numCores,ABC_time_steps=10)

write.csv(ABC_output[[k]]$final_posterior, file=paste0("PosteriorFinal_",N,"_",k,".csv"))
    }


#Loading packages
library(see)
library(transport) #For Wassertein distance computation
library(parallel) # For parallizing R codes
RNGkind("L'Ecuyer-CMRG") #Dealing with distinct seed value in R
#library(markovchain)
#library(diagram)
library('latex2exp') #For adding LaTeX symbols to R plots
library(MASS)
library("kader")
library("PerformanceAnalytics")
library(glmnet)
library("kedd")
library(bayestestR)#for credible interval and HDI+ROPE decision


setwd("/Users/twunasi-admin/Desktop/Clement_Folder/Modified ABC-SMC fitting_results_current/Modified ABC fitting_500")

#Importing posterior densities from Weighted-iterative ABC with Sequential Monte Carlo with importance sampling
draws<- c(500)
density_post<-NULL

for(n in draws){ 
    
ABC_iterations<-11
number_of_parameters<- 23
x <- seq(from = -10, to = 7, length.out = 256)#range of prior distribution
density_post[[n]]<- list()
for(j in 1:ABC_iterations) {
    density_post[[n]][[j]]<-read.csv(file=paste0("density_post_",j,"_",n,".csv"))
    density_post[[n]][[j]]<-density_post[[n]][[j]][,-1]
          }
}

parameter_labels=c(expression(paste("b"[11])),expression(paste("b"[12])),
                   expression(paste("b"[21])),expression(paste("b"[22])), 
                   expression(paste("b"[31])),expression(paste("b"[32])),
                   expression(paste("d"[11])),expression(paste("d"[12])),
                   expression(paste("d"[21])),expression(paste("d"[22])), 
                   expression(paste("d"[31])),expression(paste("d"[32])),
                   expression(paste("m")),  expression(paste("r")),
                   expression(paste("r"[1])),expression(paste("r"[2])),
                   expression(paste("r"[3])),expression(paste("s")),
                   expression(paste("s"[1])),expression(paste(epsilon[1])),
                   expression(paste(epsilon[2])),expression(paste(epsilon[3])),
                   expression(paste(kappa)))
options(repr.plot.width=8, repr.plot.height=8,repr.plot.res = 300) #Setting plot size

#All model parameters
n<-500
#par(mfrow=c(5,5), mar=c(4,0,1,0),font=2)
par(mfrow=c(5,5), mar=c(4,2,1,0),font=2)
plot(NULL ,xaxt='n',yaxt='n',bty='n', xlab="", ylab="",xlim=0:1, ylim=0:1)
plot_colors <- c("blue","red","black")
legend(x=-0.1,y=1.2,c(paste0("First Prior 
(N=",n,")"),"Intermediate 
Priors" ,"Final Posterior"),
        col=c("blue","red","black"),bty="n",cex=1.05,box.lwd = .8,fill=c("blue","red","black"),horiz=F)


for (k in 1:23) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
  
    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1,ann=FALSE,yaxt="n")
   
}

setwd("/Users/twunasi-admin/Desktop/Clement_Folder/Modified ABC-SMC fitting_results_current/Regression_adjustment_new")

Combined_posterior_adj_output<- read.csv("Post_Regression_output.csv")
Combined_posterior_adj_output<- Combined_posterior_adj_output[,-1]
rownames(Combined_posterior_adj_output)<-parameter_labels
Combined_posterior_adj_output

Posterior_adj_distn<- read.csv("Posterior_adjusted_distn_L2_500.csv")
Posterior_adj_distn<- Posterior_adj_distn[-1]
head(Posterior_adj_distn)

#Estimating the kernel density of the adjusted posterior

density_post_adjusted<- array(dim=c(number_of_parameters, 256))

for(k in 1:number_of_parameters){
density_post_adjusted[k, ]<- density(Posterior_adj_distn[ ,k], from=-10, to=7, n=256)$y
}

par(mfrow=c(3,2),mar=c(4,4,1,1))
n=500
x <- seq(from = -10, to = 7, length.out = 256)#range of prior distribution

for (k in 1:6) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="Density", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
  
    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1)
     lines(x,density_post_adjusted[k, ], col="green",lty=3,lwd=2)
      if(k==1){
    legend("topleft",c("First Prior","Intermediate Priors" ,"Unadjusted Posterior","Adjusted Posterior"),
         col=c("blue","red","black","green"),bty="n",cex=1.2,box.lwd = 2,fill=c("blue","red","black","green"))
          }
    }

n=500
par(mfrow=c(3,2),mar=c(4,4,1,1))
for (k in 7:12) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="Density", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
  
    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1)
     lines(x,density_post_adjusted[k, ], col="green",lty=3,lwd=2)
    
       if(k==8){
    legend("topleft",c("First Prior","Intermediate Priors" ,"Unadjusted Posterior","Adjusted Posterior"),
         col=c("blue","red","black","green"),bty="n",cex=1.2,box.lwd = 2,fill=c("blue","red","black","green"))
           }
    }

n=500
par(mfrow=c(3,2),mar=c(4,4,1,1))
for (k in 13:18) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="Density", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
  
    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1)
     lines(x,density_post_adjusted[k, ], col="green",lty=3,lwd=2)
    
      if(k==15){
    legend("topleft",c("First Prior","Intermediate Priors" ,"Unadjusted Posterior","Adjusted Posterior"),
         col=c("blue","red","black","green"),bty="n",cex=1.2,box.lwd = 2,fill=c("blue","red","black","green"))
          }
    }

n=500
par(mfrow=c(3,2),mar=c(4,4,1,1))
for (k in 19:23) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="Density", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
  
    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1)
     lines(x,density_post_adjusted[k, ], col="green",lty=3,lwd=2)
    
       if(k==19){
    legend("topleft",c("First Prior","Intermediate Priors" ,"Unadjusted Posterior","Adjusted Posterior"),
         col=c("blue","red","black","green"),bty="n",cex=1.2,box.lwd = 2,fill=c("blue","red","black","green"))
           }
    }





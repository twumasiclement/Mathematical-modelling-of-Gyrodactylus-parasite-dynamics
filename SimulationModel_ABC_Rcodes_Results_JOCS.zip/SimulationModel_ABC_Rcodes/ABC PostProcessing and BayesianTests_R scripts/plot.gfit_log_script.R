
plot.gfit_log=function(x, xlim=NULL,ylim=NULL, y_legend=NULL, legend_add=FALSE, breaks="Freedman-Diaconis",
                       main="Histogramme of the null distribution", xaxt = NULL,cex=NULL,
                       cex.lab=NULL, cex.axis=NULL,xlab=NULL,
                       ...){
  
  if (!inherits(x, "gfit")) 
    stop("Use only with objects of class \"gfit.\"", call.=F)
  
  dist.sim=x$dist.sim
  dist.obs=x$dist.obs
  et=max(dist.sim)-min(dist.sim)
  inf=min(min(dist.sim), dist.obs)-0.1*et
  sup=max(max(dist.sim), dist.obs)+0.1*et
  
  hist(log(dist.sim), prob=T, xlab=xlab, xlim=xlim,ylim=ylim,
       breaks=breaks, main=main, col="blue", xaxt= xaxt ,cex.lab=cex.lab,cex=cex,las=1,
       ...)
  abline(v=log(dist.obs), col="green", pch=5, lwd=2)
  # legend(x=5, y=y_legend, legend="Observed distance", cex=0.8, col=4, lty=1, lwd=2)
  
  if(legend_add==TRUE){
    
    legend(x=0.65, y=y_legend,c("Simulated ABC goodness-of-fit statistic" ,"Observed ABC goodness-of-fit statistic"),
           col=c("blue","green"),bty="n",cex=1.2,box.lwd = 1,fill=c("blue","green"),ncol=2)
  }
}

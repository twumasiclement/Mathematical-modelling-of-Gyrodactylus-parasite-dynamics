#Creating a function for Multivariate Kruskal Wallis test
multkw<- function(group,y,simplify=FALSE){
  ### sort data by group ###
  o<-order(group)
  group<-group[o]
  y<-as.matrix(y[o,])
  n<-length(group)
  k<-dim(y)[2]   #k=p
  
  if (dim(y)[1] != n)
    return("number of observations not equal to length of group")
  groupls<-unique(group)
  g<-length(groupls) #number of groups (Number of fish-parasite combination)#
  groupind<-sapply(groupls,"==",group) #group indicator#
  ni<-colSums(groupind) #num of subj of each group (Number of fish in each group)#
  r<-apply(y,2,rank) #corresponding rank variable (Parasite at each bodyparts)#
  
  ### calculation of statistic ###
  r.ik<-t(groupind)%*%r*(1/ni)  #gxp, mean rank of kth variate in ith group#
  m<- (n+1)/2 #expected value of rik#
  u.ik<-t(r.ik-m)
  U<-as.vector(u.ik)
  V<-1/(n-1)*t(r-m)%*%(r-m) #pooled within-group cov matrix
  Vstar<-bdiag(lapply(1/ni,"*",V))
  W2<-as.numeric(t(U)%*%solve(Vstar)%*%U)
  
  ### return stat and p-value ###
  returnlist<-data.frame(statistic=W2,d.f.=k*(g-1),
                         p.value=pchisq(W2,k*(g-1),lower.tail=F))
  
  if (simplify==TRUE) return (W2)
  else return (returnlist)
}
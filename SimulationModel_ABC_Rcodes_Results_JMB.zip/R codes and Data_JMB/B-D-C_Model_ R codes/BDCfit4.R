library(JuliaCall)
#julia_command('BDCdir = "/home/owen/OneDrive CU/Work Documents/Research/Current/BDCsim_fit"') # location of BDCfit.jl
julia_command('BDCdir = "C:/Users/user/AppData/Local/Programs/Julia 1.5.3/bin"') # location of BDCfit.jl
julia_command("push!(LOAD_PATH, BDCdir)")
julia_command("using BDCfit")

x <- matrix(c(2, 3, 5, 8, 13, 20, 30, 35, 50,
              4, 3, 7, 10, 20, -1, -1, -1, -1,
              1, 0, 0, 0, 0, 0, 0, 0, 0), 3, 9, byrow=TRUE)
julia_call("logL", .3, .2, .001, x)


#ProbBDC(lambda, mu, rho, t, mmax, nmax)
P1 <- julia_call("ProbBDC", .3, .2, .001, 1, 100, 100)
P1

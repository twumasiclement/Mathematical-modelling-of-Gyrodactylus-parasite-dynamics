#Loading packages
#library(see)
library(transport) #For Wassertein distance computation
library(parallel) # For parallizing R codes
RNGkind("L'Ecuyer-CMRG") #Dealing with distinct seed value in R
#library(markovchain)
#library(diagram)
library('latex2exp') #For adding LaTeX symbols to R plots
library(compiler)# byte code compilation
#library(data.table)
library("maxLik")#for maximum likelihood estimation/optimization
library("miscTools") 
library("R.utils")
library(MASS)
library("kader")
library("PerformanceAnalytics")
library(glmnet)
library(caret)
#library("kedd")
library(bayestestR)#for credible interval and HDI+ROPE decision
library("sjstats")#for HDI+ROPE decision
library(abind)
#library(sjmisc)
#library(rstanarm)
#library("HDInterval")
#library("LaplacesDemon")
library(dplyr)


library(ggplot2)
library(tidyverse)
library(lme4)
#library(merTools)
library(glmmTMB) # fitting generalised linear mixed models
library(bbmle) # general maximum likelihood estimation
#library(ggthemes)
library(showtext)
library("ggpubr")


theme_set(theme_bw()+
theme(panel.spacing=grid::unit(0,"lines")))
#library(sjPlot) #for plotting lmer and glmer mods
library(sjmisc) 
library(effects)
#library(sjstats) #use for r2 functions
library(jtools)
library(forcats)
library(rstatix)
library("sjPlot")

#Setting working directory
setwd("C:/Users/twuma/OneDrive - Imperial College London/Desktop/GyroSim_Model")

#Setting plot size and resolution
options(repr.plot.width=8, repr.plot.height=8,repr.plot.res = 500) #Setting plot size

#Importing posterior densities from Weighted-iterative ABC with Sequential Monte Carlo with importance sampling
setwd(paste0(getwd(),"/Regression_adjust_SimulationModel_new"))
draws<- c(500)
density_post<-NULL

for(n in draws){ 
    
ABC_iterations<-11
number_of_parameters<- 23
x <- seq(from = -10, to = 7, length.out = 256)#range of prior distribution
density_post[[n]]<- list()
for(j in 1:ABC_iterations) {
    density_post[[n]][[j]]<-read.csv(file=paste0("density_post_",j,"_",n,".csv"))
    density_post[[n]][[j]]<-density_post[[n]][[j]][,-1]
          }
}

#Assigning parameter labels for the 23 model parameters
parameter_labels<-c(expression(paste("b"[11])),expression(paste("b"[12])),
                   expression(paste("b"[21])),expression(paste("b"[22])), 
                   expression(paste("b"[31])),expression(paste("b"[32])),
                   expression(paste("d"[11])),expression(paste("d"[12])),
                   expression(paste("d"[21])),expression(paste("d"[22])), 
                   expression(paste("d"[31])),expression(paste("d"[32])),
                   expression(paste("m")),  expression(paste("r")),
                   expression(paste("r"[1])),expression(paste("r"[2])),
                   expression(paste("r"[3])),expression(paste("s")),
                   expression(paste("s"[1])),expression(paste(epsilon[1])),
                   expression(paste(epsilon[2])),expression(paste(epsilon[3])),
                   expression(paste(kappa)))

#All model parameters
n<-500
#par(mfrow=c(5,5), mar=c(4,0,1,0),font=2)
par(mfrow=c(5,5), mar=c(4,2,1,0),font=2)
plot(NULL ,xaxt='n',yaxt='n',bty='n', xlab="", ylab="",xlim=0:1, ylim=0:1)
plot_colors <- c("blue","red","black")
legend(x=-0.1,y=1.2,c(paste0("First Prior 
(N=",n,")"),"Intermediate 
Priors" ,"Final Posterior"),
        col=c("blue","red","black"),bty="n",cex=1.05,box.lwd = .8,fill=c("blue","red","black"),horiz=F)


for (k in 1:23) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
  
    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1,ann=FALSE,yaxt="n")
   
}

#Setting working directory
setwd("C:/Users/twuma/OneDrive - Imperial College London/Desktop/GyroSim_Model")


#### External scripts for the simulation model and ABC #####

#Script of function for computing event rates
source("Computing-rates-script.r")

# Script of function for updating exact SSA
source("Update-exactSSA-script.r")

# Script of function for updating tau-leaping
source("Update-tauleaping-script.r")

# Script of function experimental descriptors 
# (fish type, strain, fish size, fish sex and areas of the 4 body regions)
source("Descriptors-Data-script.r")

# Script of function for simulating parasites only a single fish over time and across body regions
source("Simulation-single-fish-script.r")

# Script of function for simulating parasites for a group fish over time and across body regions
#Corresponding to the empirical data
source("Simulation-Group-fish-script.r")

#Script of functions for Galton-Watson & GMM estimation of the B-D-C parameters
source("MLE_catastrophe-script.r")
source("GMM-1st2nd-Steps-script.r")
source("BDC-GW-GMM-estimator-script.r")

#Script for population projection until day 17 after fish death to aid with ABC fitting
source("Project-Parasite-script.r")

#Script for function used to compute the 17 summary statistics for ABC fitting:
#1.Log count across time (9)
#2.Wasserstein distance between the four body regions (4),
#3.Estimates of the B-D-C model parameters (3)
#4.Time before death (1)
source("summary-stats-ABC-script.r")


#Script of function for combining the 17 summary statistics
source("combine-summary-stats-script.R")

#Function for posterior adjustment using Weighted Ridge and Lasso regression, respectively
source("Post-Ridge-reg-adj-L2-script.R")#ABC Post processing-Ridge/l2 correction
source("Post-Lasso-reg-adj-L1-script.R")#ABC Post processing-Lasso/L1 correction

#To detect the number of processors or cores of your computer 
numCores<-min(16,detectCores())
numCores

#Importing empirical data 
Combined_data <- read.csv(file="Parasite_Data.csv") 
#Importing data for area of the 8 body parts across 18 fish (measured in millimeters square)
Bodyparts_area<-read.csv(file="Area_Fish_bodyParts.csv")

#Experimental descriptors
Descriptors<- Experiment_descriptors(empirical_data=Combined_data)

fishSize <- Descriptors$fishSize #fish size
fishSex  <- Descriptors$fishSex #fish sex
Strain   <- Descriptors$Strain # parasite strain
Fish_stock<-Descriptors$Fish_stock #fish stock
numF    <-  Descriptors$numF # total fish for each parasite-fish group 
fishID  <-  Descriptors$fishID # fish IDs for each parasite-fish group 
pop_obs <-  Descriptors$pop_obs # observed parasite numbers for each parasite-fish group 
alive_obs<- Descriptors$alive_obs # observed surviva status for each parasite-fish group 
Area_normalized<- Body_area(Area_data=Bodyparts_area)#body areas

#Parasite-fish groups
parasite_fish<-c("Gt3-OS","Gt3-LA","Gt3-UA","Gt-OS","Gt-LA","Gt-UA","Gb-OS","Gb-LA","Gb-UA")

#summaries_obs[[1]]
setwd("C:/Users/twuma/OneDrive - Imperial College London/Desktop/GyroSim_Model")

setwd(paste0(getwd(),"/Regression_adjust_SimulationModel_new"))
#Importing final posterior at different sample sizes of initial prior distn
Final_posterior<-NULL
draws<- c(500)
for (n in draws){
  Final_posterior[[n]]<- read.csv(paste0("PosteriorFinal_", n, ".csv"))
  Final_posterior[[n]]<-Final_posterior[[n]][,-1]
  #print(paste("draws=",n))
  #print(Final_posterior[[n]])
}

#Estimating the 95% Credible interval for the unadjusted posterior
ci_eti<- NULL;Posterior_estimates_unadj<- NULL

for(n in draws){
  #computing credible intervals (ETI)
  post_data<-   Final_posterior[[n]]
  ci_eti[[n]]<- ci(as.data.frame(post_data), ci = 0.95,method = "ETI") 
  ci_eti[[n]]<- exp(as.data.frame(ci_eti[[n]][,3:4]))
   # estimating the  posterior  mean estimate
  Posterior_estimates_unadj[[n]]<- apply(exp(Final_posterior[[n]]),2,mean)
    }

Posterior_est_unadj_data<- data.frame(Posterior_estimate_unadj=Posterior_estimates_unadj[[500]],
                                     Cred_Int_lower95_unadj= ci_eti[[500]][,1],
                                     Cred_Int_upper95_unadj= ci_eti[[500]][,2])

#Print unadjusted posterior estimates with 95% credible intervals
Posterior_est_unadj_data

time_CPU<- NULL
for(n in draws) {
    time_CPU[[n]]<- read.csv(file=paste0("CPUtime_",n,".csv"))
    time_CPU[[n]]<- time_CPU[[n]][,-1]
    }

#Computational times
 for(i in seq_along(draws))  print(paste("CPU time at N=", draws[i],"",":",time_CPU[[draws[i]]]/10,"secs"))

 for(i in seq_along(draws))  print(paste("CPU time at N=", draws[i],"",":",time_CPU[[draws[i]]]/864000,"days"))

#Converting from seconds to days
  library(lubridate)
 for(i in seq_along(draws))  print(paste("CPU time at N=", draws[i],"",":",seconds_to_period(time_CPU[[draws[i]]]/10)))

w_distance <- function(S1, S2, weight)  {
  n<- dim(S1)[1]
  Squared_diff_mat<- (S1-S2)^2 #squared difference between matrix S1 & S2
  #Multiplying vector to weights to each rows of  Squared_diff_mat
  Weighted_sq_diff<- lapply(1:dim(S1)[1],
              function(k) weight*Squared_diff_mat[k, ])
  WSS<- do.call("sum",Weighted_sq_diff)#total weighted distances (WSS)
  return(sqrt(WSS/n))#return weighted sum of square distance 
}

#Function to compute and combine summary statistics given data
SummaryStats_func<- function(X0=2,pop,alive,group=parasite_fish){
    # B-D-C parameter estimates for the parasite-fish groups based on observed data
    BDC_estimates<- GW_GMM_BDCestimator(X0=2,pop=pop,alive=alive,
                                        group=group)$BDC_estimates
    #Computing summary statistics for data across the parasite-fish groups
    summaries<- Summary_stats(pop=pop,alive=alive,BDC_estimates=BDC_estimates)
    
    #Combining summary statistics across all observed fish
    SummaryStats_combined<- do.call("rbind", summaries)
    
    #Pooled summary across all fish
    pooled_summary<- apply(SummaryStats_combined,2,mean)
    pooled_summary<- as.data.frame(t(pooled_summary))#converting results to 1 by dimS=17 data frame
    return(list(pooled_summary=pooled_summary,SummaryStats_combined=SummaryStats_combined))
    
}



SummaryStats_obs_combined<-SummaryStats_func(X0=2,pop=pop_obs,alive=alive_obs,group=parasite_fish)$SummaryStats_combined

#Initial simulation inputs for A (parasite numbers) and  B (immune status)
A0 <- matrix(0, 4, 2)  
A0[1, 1] <- 2   #Intial parasites at the tail
B0 <- rep(1, 4)  #initial immune response at 4 body regions (no response)

#Transition matrix
J<- matrix(c(0,    1,    0,     0, 
             1/2,   0,    1/2,   0,
             0,    1/2,    0,   1/2,
             0,     0,     1,    0), 4, 4, byrow=TRUE)

Reg_adjust_L2<- function(i) Post_Ridge_reg_adj(post_distn=Final_posterior[[draws[i]]],
                                    summary_obs= SummaryStats_obs_combined)

Output_adj_Ridge<- lapply(seq_along(draws),Reg_adjust_L2)

set.seed(12) #for reproducibility
Reg_adjust_L1<- function(i) Post_Lasso_reg_adj(post_distn=Final_posterior[[draws[i]]],
                                    summary_obs= SummaryStats_obs_combined)

Output_adj_Lasso<- lapply(seq_along(draws),Reg_adjust_L1)

#Estimated regression coefficients from Lasso correction (with summary statistics dimension reduction)
#Output_adj_Lasso[[1]]$beta_lasso

X_matrix<- as.data.frame(Output_adj_Ridge[[1]]$X_Design_matrix)

for (i in 1:dim(X_matrix)[2]) names(X_matrix)[i]<- paste0("S_",i)

chart.Correlation(X_matrix, histogram=TRUE, pch=19)

#Importing final posterior at different sample sizes of initial prior distn
Ridge_Adjusted_posterior<-NULL;Lasso_Adjusted_posterior<-NULL
draws<- c(500)

for (n in draws){
    #On log scale
  Ridge_Adjusted_posterior[[n]]<- Output_adj_Ridge[[1]]$Adjusted_posterior_dist
  Lasso_Adjusted_posterior[[n]]<- Output_adj_Lasso[[1]]$Adjusted_posterior_dist
}

n<-draws
#Estimating the 95% Credible interval for the unadjusted posterior
ci_eti_Ridge_adj<- NULL;Posterior_estimates_Ridge_adj<- NULL
ci_eti_Lasso_adj<- NULL;Posterior_estimates_Lasso_adj<- NULL

 ####Computing credible intervals (ETI)---For Ridge adjustment##########
  Ridge_post_data<-  Ridge_Adjusted_posterior[[n]]
  #Estimated Credible Intervals On log scale
  ci_eti_Ridge_adj[[n]]<- as.data.frame(ci(as.data.frame(Ridge_post_data), ci = 0.95,method = "ETI"))[,3:4]
 #Estimated Credible Intervals On Original scale
  ci_eti_Ridge_adj[[n]]<- exp(ci_eti_Ridge_adj[[n]])
   # estimating the  posterior  mean estimate
  Posterior_estimates_Ridge_adj[[n]]<- Output_adj_Ridge[[1]]$Posterior_mean_output[,1]
    

Posterior_est_Ridge_adj_data<- data.frame(Ridge_Posterior_estimate_adj=Posterior_estimates_Ridge_adj[[500]],
                                     Ridge_Cred_Int_lower95_adj= ci_eti_Ridge_adj[[500]][,1],
                                     Ridge_Cred_Int_upper95_adj= ci_eti_Ridge_adj[[500]][,2])


#Print Ridge adjusted and unadjusted posterior estimates with 95% credible intervals
Combined_posterior_Ridge_adj_unadj<- cbind(Posterior_est_Ridge_adj_data,Posterior_est_unadj_data)


#Save output
write.csv(Combined_posterior_Ridge_adj_unadj,"Post_Ridge_Regression_output.csv")



 ####Computing credible intervals (ETI)---For Ridge adjustment##########
  Lasso_post_data<-  Lasso_Adjusted_posterior[[n]]
  #Estimated Credible Intervals On log scale
  ci_eti_Lasso_adj[[n]]<- as.data.frame(ci(as.data.frame(Lasso_post_data), ci = 0.95,method = "ETI"))[,3:4]
 #Estimated Credible Intervals On Original scale
  ci_eti_Lasso_adj[[n]]<- exp(ci_eti_Lasso_adj[[n]])
   # estimating the  posterior  mean estimate
  Posterior_estimates_Lasso_adj[[n]]<- Output_adj_Lasso[[1]]$Posterior_mean_output[,1]
    

Posterior_est_Lasso_adj_data<- data.frame(Lasso_Posterior_estimate_adj=Posterior_estimates_Lasso_adj[[500]],
                                     Lasso_Cred_Int_lower95_adj= ci_eti_Lasso_adj[[500]][,1],
                                     Lasso_Cred_Int_upper95_adj= ci_eti_Lasso_adj[[500]][,2])


#Print Lasso adjusted and unadjusted posterior estimates with 95% credible intervals
Combined_posterior_Lasso_adj_unadj<- cbind(Posterior_est_Lasso_adj_data,Posterior_est_unadj_data)


#Save output
write.csv(Combined_posterior_Lasso_adj_unadj,"Post_Lasso_Regression_output.csv")



#Importing previously saved ABC Ridge post-processing results
setwd("C:/Users/twuma/OneDrive - Imperial College London/Desktop/GyroSim_Model")


Post_Ridge_Regression_output<- read.csv("Post_Ridge_Regression_output.csv")
Post_Ridge_Regression_output<- Post_Ridge_Regression_output[,-1]



Post_Lasso_Regression_output<- read.csv("Post_Lasso_Regression_output.csv")
Post_Lasso_Regression_output<- Post_Lasso_Regression_output[,-1]

setwd("C:/Users/twuma/OneDrive - Imperial College London/Desktop/GyroSim_Model")

#Saving Ridge and Lasso adjusted posterior distributions 
write.csv(Output_adj_Ridge[[1]]$Adjusted_posterior_dist,
                        paste0("Posterior_Ridge_adj_distn_log_",draws,".csv"))


write.csv(Output_adj_Lasso[[1]]$Adjusted_posterior_dist,
                        paste0("Posterior_Lasso_adj_distn_log_",draws,".csv"))

setwd("C:/Users/twuma/OneDrive - Imperial College London/Desktop/GyroSim_Model")
#Importing adjusted and unadjusted posterior distributions
Posterior_Ridge_adj_distn_log<- read.csv("Posterior_Ridge_adj_distn_log_500.csv")
Posterior_Ridge_adj_distn_log<- Posterior_Ridge_adj_distn_log[,-1]


Posterior_Lasso_adj_distn_log<- read.csv("Posterior_Lasso_adj_distn_log_500.csv")
Posterior_Lasso_adj_distn_log<- Posterior_Lasso_adj_distn_log[,-1]



Posterior_Unadj__distn_log<- read.csv("Posterior_unadj_distn_log_500.csv")
Posterior_Unadj__distn_log<- Posterior_Unadj__distn_log[,-1]

Variance<-list()


Variance[["Ridge"]]<- apply(Posterior_Ridge_adj_distn_log,2,var)
Variance[["Lasso"]]<- apply(Posterior_Lasso_adj_distn_log,2,var)
Variance[["Unadj_post"]]<- apply(Posterior_Unadj__distn_log,2,var)



df<- data.frame(Var_unadj_posterior=Variance[["Unadj_post"]],Var_Ridge_posterior= Variance[["Ridge"]],
          Var_Lasso_posterior= Variance[["Lasso"]])


rownames(df)<- paste(parameter_labels)
df

VarTest_df<- rbind(Posterior_Unadj__distn_log,Posterior_Ridge_adj_distn_log,Posterior_Lasso_adj_distn_log)

VarTest_df$Methods<- c(rep("Unadj-ABC_SMC",10),rep("Ridge_adj",10),rep("Lasso_adj",10))

## Fligner-Killeen Test of Homogeneity of Variances
VarTest_pvalues_parameters<- rep(NA, length=23)
for (i in 1:23){
    var_test_res<- fligner.test(VarTest_df[,i] ~Methods, data = VarTest_df)
    VarTest_pvalues_parameters[i]<-  var_test_res$p.value
   }

options(repr.plot.width=8, repr.plot.height=8,repr.plot.res = 500) #Setting plot size

options(warn=-1)
#par(las=2.5)



plot(Variance[["Unadj_post"]],type="h",col="red",ylim=c(0,.06),xlim=c(0,25),
    xaxt="n",las=2,cex.names=0.3,cex.axis=0.8,ylab="Variance",
     xlab="Model parameters", pch=19,lwd=2)

axis(1, at=1:23, labels=parameter_labels,font=3, hadj = .9,cex.names=0.8,cex.axis=.8)


lines(Variance[["Unadj_post"]],type="p",col="red",pch=19,lwd=0.5)
lines(Variance[["Ridge"]],type="p",col="blue",pch=3,lwd=1.5)
lines(Variance[["Lasso"]],type="p",col="green",pch=4,lwd=1.5)


legend(x=12.7,y=.061,legend=c("Unadjusted posterior","Ridge adjustment","Lasso adjustment"),
        col=c("red","blue","green"),pch=c(19,3,4),
       cex=1,box.lwd = 2,ncol =1,title="Method")

specify_decimal <- function(x, k) trimws(format(round(x, k), nsmall=k))

text(Variance[["Lasso"]]+c(0.001,0, 0.003, 0,0.001, rep(0,7),0.002,rep(0,4), 0.0015, rep(0, 3),0.001,0), 
     paste0("p=",specify_decimal(VarTest_pvalues_parameters,3)),pos=c(3), cex=0.69,font=2)

#The variance from the Ridge adjustment was less in 13 out of the 23 model paramaters
table(Variance[["Ridge"]]<Variance[["Lasso"]])
VarTest_df_exp<- exp( VarTest_df[,1:23])
Groups<- c(rep("Unadj-ABC_SMC",10),rep("Ridge_adj",10),rep("Lasso_adj",10))

Posterior_distn<-  VarTest_df_exp[,1:23]


source("MKW_test_script.R")#Script for MKW test

MKW_test<- multkw(group=Groups,y=Posterior_distn,simplify=FALSE)
MKW_test
library("overlapping")

overlap_data_list<- NULL

overlap_Unadj_post_vs_Ridge<- rep(NA,23);overlap_Unadj_post_vs_Lasso<-rep(NA,23);overlap_Ridge_vs_Lasso<-rep(NA,23)

for(i in 1:23){
    
  x <- list(Unadj_posterior=Posterior_Unadj__distn_log[,i],
          Ridge=Posterior_Ridge_adj_distn_log[,i], Lasso=Posterior_Lasso_adj_distn_log[,i])
  out<-  overlap(x)
  out_pairs<- as.numeric(out$OVPairs)
  overlap_data_list[[i]]<-data.frame(Overlap_index=out_pairs, 
                        Comparison_methods=c("Unadj_posterior-Ridge","Unadj_posterior-Lasso","Ridge-Lasso"),
                        Parameters= rep(paste(parameter_labels[i]),3)) 
    
  overlap_Unadj_post_vs_Ridge[i]<- out_pairs[1]
  overlap_Unadj_post_vs_Lasso[i]<-  out_pairs[2]
  overlap_Ridge_vs_Lasso[i]<-  out_pairs[3]
}



options(warn=-1)
percent<-100
plot(overlap_Unadj_post_vs_Ridge*percent,type="b",col="red",ylim=c(0,1.3*percent),xlim=c(0,25),
    xaxt="n",las=2,cex.names=0.3,cex.axis=0.8,ylab="Estimated overlap index (%)",
     xlab="Model parameters", pch=1,lwd=1)

axis(1, at=1:23, labels=parameter_labels,font=3, hadj = .9,cex.names=0.8,cex.axis=.8)


#lines(overlap_Unadj_post_vs_Ridge*percent,type="p",col="red",pch=19,lwd=0.5)
lines( overlap_Unadj_post_vs_Lasso*percent,type="b",col="blue",pch=3,lwd=2)
lines(overlap_Ridge_vs_Lasso*percent,type="b",col="green",pch=4,lwd=1)


legend(x=5,y=1.35*percent,legend=c("Unadjusted posterior vs Ridge adjustment",
                              "Unadjusted posterior vs Lasso adjustment",
                              " Ridge adjustment vs Lasso adjustment"),
        col=c("red","blue","green"),pch=c(1,3,4),
       cex=1,box.lwd = 2,ncol =1,title="Pairwise comparison:",bty="n")


#do.call("rbind",overlap_data_list)

#Estimating the kernel density of the adjusted posterior

density_post_Ridge_adjusted<- array(dim=c(number_of_parameters, 256))
density_post_Lasso_adjusted<- array(dim=c(number_of_parameters, 256))

for(k in 1:number_of_parameters){
  density_post_Ridge_adjusted[k, ]<- density(Posterior_Ridge_adj_distn_log[ ,k], from=-10, to=7, n=256)$y
  density_post_Lasso_adjusted[k, ]<- density(Posterior_Lasso_adj_distn_log[ ,k], from=-10, to=7, n=256)$y
}

par(mfrow=c(3,2),mar=c(4,4,1,1))
n=500
x <- seq(from = -10, to = 7, length.out = 256)#range of prior distribution

for (k in 1:6) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="Density", col="blue",cex.lab=1.2,lwd=2.5,las=1) 

 if(k==1) legend("topleft",c("First Prior","Intermediate Priors" ,"Unadjusted Posterior","Ridge Adjustment","Lasso Adjustment"),
         col=c("blue","red","black","green","orange"),bty="n",cex=1,box.lwd = 2,fill=c("blue","red","black","green","orange"))

    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1)
     lines(x,density_post_Ridge_adjusted[k, ], col="green",lty=3,lwd=2)
      lines(x,density_post_Lasso_adjusted[k, ], col="orange",lty=3,lwd=2)
   
    }

par(mfrow=c(3,2),mar=c(4,4,1,1))
n=500
x <- seq(from = -10, to = 7, length.out = 256)#range of prior distribution

for (k in 7:12) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="Density", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
  
 if(k==8) legend("topleft",c("First Prior","Intermediate Priors" ,"Unadjusted Posterior","Ridge Adjustment","Lasso Adjustment"),
         col=c("blue","red","black","green","orange"),bty="n",cex=1,box.lwd = 2,fill=c("blue","red","black","green","orange"))
    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1)
     lines(x,density_post_Ridge_adjusted[k, ], col="green",lty=3,lwd=2)
      lines(x,density_post_Lasso_adjusted[k, ], col="orange",lty=3,lwd=2)
   
    }

par(mfrow=c(3,2),mar=c(4,4,1,1))
n=500
x <- seq(from = -10, to = 7, length.out = 256)#range of prior distribution

for (k in 13:18) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="Density", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
  
 if(k==14) legend("topright",c("First Prior","Intermediate Priors" ,"Unadjusted Posterior","Ridge Adjustment","Lasso Adjustment"),
         col=c("blue","red","black","green","orange"),bty="n",cex=1,box.lwd = 2,fill=c("blue","red","black","green","orange"))
    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1)
     lines(x,density_post_Ridge_adjusted[k, ], col="green",lty=3,lwd=2)
      lines(x,density_post_Lasso_adjusted[k, ], col="orange",lty=3,lwd=2)
    
    }

par(mfrow=c(3,2),mar=c(4,4,1,1))
n=500
x <- seq(from = -10, to = 7, length.out = 256)#range of prior distribution

for (k in 19:23) {
  plot(x, density_post[[n]][[1]][k, ], type="l", ylim=c(0,5),
       xlab=parameter_labels[k],ylab="Density", col="blue",cex.lab=1.2,lwd=2.5,las=1) 
 
  if(k==19) legend("topleft",c("First Prior","Intermediate Priors" ,"Unadjusted Posterior","Ridge Adjustment","Lasso Adjustment"),
         col=c("blue","red","black","green","orange"),bty="n",cex=1,box.lwd = 2,fill=c("blue","red","black","green","orange"))

    
  for (j in 2:10) {
    lines(x,density_post[[n]][[j]][k, ], yaxt= "n",col="red",lwd=1,pch=4,ann=FALSE,yaxt="n")
  }
    
     lines(x, density_post[[n]][[11]][k, ], col="black", lwd=1)
     lines(x,density_post_Ridge_adjusted[k, ], col="green",lty=3,lwd=2)
      lines(x,density_post_Lasso_adjusted[k, ], col="orange",lty=3,lwd=2)
   
    }

#The 9 parasite-host groups 
parasite_fish

print(paste("ABC unadjusted posterior estimates at N=",draws[1]))
Parameter_estimates_unadj<- Post_Ridge_Regression_output[,4]
print(Parameter_estimates_unadj)

print(paste("Proposed Ridge adjusted posterior estimates at N=",draws[1]))
Parameter_estimates_ridge<- Post_Ridge_Regression_output[,1]
print(Parameter_estimates_ridge)


print(paste("Proposed Lasso adjusted posterior estimates at N=",draws[1]))
Parameter_estimates_lasso<- Post_Lasso_Regression_output[,1]
print(Parameter_estimates_lasso)

#Simulations based on the unadjusted posterior##########################
rep<-1383 #Number of replicates/repetition
output_sim_unadj1<- NULL
for(i in 1:rep){
    #set.seed(i)
    output_sim_unadj1[[i]]<- SimGroup_tauleap(theta1=log(Parameter_estimates_unadj),
            fish_sex=fishSex,fish_type=Fish_stock,strain=Strain,fish_size=fishSize,error=0.01)
    }

#Simulations based on the Ridge adjusted posterior#########################

rep<-1383 #Number of replicates/repetition
output_sim_ridge1<- NULL
for(i in 1:rep){
     #set.seed(i)
    output_sim_ridge1[[i]]<- SimGroup_tauleap(theta1=log(Parameter_estimates_ridge),
            fish_sex=fishSex,fish_type=Fish_stock,strain=Strain,fish_size=fishSize,error=0.01)
    }

#Simulations based on the Lasso adjusted posterior
rep<- 1383 # Number of replicates/repetition
output_sim_lasso1<- NULL
for(i in 1:rep){
     #set.seed(i)
    output_sim_lasso1[[i]]<- SimGroup_tauleap(theta1=log(Parameter_estimates_lasso),
            fish_sex=fishSex,fish_type=Fish_stock,strain=Strain,fish_size=fishSize,error=0.01)
    }

#Pooled summary statistics
Pooled_SummaryStats_obs<-SummaryStats_func(X0=2,pop=pop_obs,alive=alive_obs,group=parasite_fish)$pooled_summary

#Pooled summary statistics based on Unadjusted posterior
Unadj_SummaryStats_sim_combined_rep<- NULL
for(i in 1:rep) Unadj_SummaryStats_sim_combined_rep[[i]]<- SummaryStats_func(X0=2,pop=output_sim_unadj1[[i]]$pop_sim,
                                alive=output_sim_unadj1[[i]]$alive_sim,group=parasite_fish)$pooled_summary

Pooled_SummaryStats_unadj<- do.call("rbind",Unadj_SummaryStats_sim_combined_rep)
write.csv(Pooled_SummaryStats_unadj,"Pooled_SummaryStats_unadj.csv")


#Pooled summary statistics based on Ridge-posterior adjustment
Ridge_SummaryStats_sim_combined_rep<- NULL
for(i in 1:rep) Ridge_SummaryStats_sim_combined_rep[[i]]<- SummaryStats_func(X0=2,pop=output_sim_ridge1[[i]]$pop_sim,
                                alive=output_sim_ridge1[[i]]$alive_sim,group=parasite_fish)$pooled_summary

Pooled_SummaryStats_ridge<- do.call("rbind",Ridge_SummaryStats_sim_combined_rep)
write.csv(Pooled_SummaryStats_ridge,"Pooled_SummaryStats_ridge.csv")

#Pooled summary statistics based on Lasso-posterior adjustment
Lasso_SummaryStats_sim_combined_rep<- NULL
for(i in 1:rep) Lasso_SummaryStats_sim_combined_rep[[i]]<- SummaryStats_func(X0=2,pop=output_sim_lasso1[[i]]$pop_sim,
                                alive=output_sim_lasso1[[i]]$alive_sim,group=parasite_fish)$pooled_summary

Pooled_SummaryStats_lasso<- do.call("rbind",Lasso_SummaryStats_sim_combined_rep)
write.csv(Pooled_SummaryStats_lasso,"Pooled_SummaryStats_lasso.csv")

#Importing the saved results
Pooled_SummaryStats_unadj_df<- read.csv("Pooled_SummaryStats_unadj.csv")
Pooled_SummaryStats_unadj_df<-Pooled_SummaryStats_unadj_df[,-1]

Pooled_SummaryStats_ridge_df<- read.csv("Pooled_SummaryStats_ridge.csv")
Pooled_SummaryStats_ridge_df<- Pooled_SummaryStats_ridge_df[,-1]

Pooled_SummaryStats_lasso_df<- read.csv("Pooled_SummaryStats_lasso.csv")
Pooled_SummaryStats_lasso_df<- Pooled_SummaryStats_lasso_df[,-1]

Summaries_Combined_df<- rbind(Pooled_SummaryStats_unadj_df,Pooled_SummaryStats_ridge_df,
                             Pooled_SummaryStats_lasso_df)

dim(Summaries_Combined_df)

library(abc) #for ABC Goodness-of-fit

reps<- dim(Pooled_SummaryStats_unadj_df)[1]
reps

ABC_methods<- c(rep("Unadjusted posterior",length=reps),
                rep("Ridge adjustment",length=reps),
               rep("Lasso adjustment",length=reps))
length(ABC_methods)
ABC_methods<- factor(ABC_methods, levels=c("Unadjusted posterior","Ridge adjustment","Lasso adjustment"))
levels(ABC_methods)


#NB: statistic= define the goodness-of-fit statistic. Typical values are median (default), mean, or max. 
#When using median fo instance, the g.o.f. statistic is the median of the distance
#Based on unadjusted posterior
#set.seed(11111232)
set.seed(1234)
tols<-0.01; nb.rep<- 78 
abc_gof_test_unadj<- gfit(target=Pooled_SummaryStats_obs, 
                    sumstat= Pooled_SummaryStats_unadj_df, 
                    nb.replicate=nb.rep, tol=tols, statistic=median, trace=FALSE)

paste("Method: Unadjusted posterior")
summary(abc_gof_test_unadj)

#Ridge-posterior correction
abc_gof_test_ridge<- gfit(target=Pooled_SummaryStats_obs, 
                    sumstat=Pooled_SummaryStats_ridge_df, 
                    nb.replicate=nb.rep, tol=tols, statistic=median, trace=FALSE)

paste("Method: Ridge adjustment")
summary(abc_gof_test_ridge)


#Lasso-posterior correction
abc_gof_test_lasso<- gfit(target=Pooled_SummaryStats_obs, 
                    sumstat=Pooled_SummaryStats_lasso_df, 
                    nb.replicate=nb.rep, tol=tols, statistic=median, trace=FALSE)

paste("Method: Lasso adjustment")
summary(abc_gof_test_lasso)

#How the p-value was obtained: The p-value= the proportion of times
#the simulated test statistic exceeded the observed test statistic
mean(abc_gof_test_ridge$dist.sim>abc_gof_test_ridge$dist.obs)


#the simulated test statistic exceeded the observed test statistic
mean(abc_gof_test_lasso$dist.sim>abc_gof_test_lasso$dist.obs)

mean(abc_gof_test_unadj$dist.sim>abc_gof_test_unadj$dist.obs)

source("plot.gfit_log_script.R")
par(mfrow=c(3,1))
o<-par(mar=c(0,4,2,2))#Run this before the code below
specify_decimal <- function(x, k) trimws(format(round(x, k), nsmall=k))
nf<-layout(matrix(1:3, nrow=3,ncol=1))

    
# rest parameters
par(o)#
o<-par(mar=c(0,4,2,2))

break_s<- 60#"Sturges" #"Freedman-Diaconis"
plot.gfit_log(abc_gof_test_unadj,breaks=break_s,xlim=c(1,7),legend_add=T,
              main="",y_legend=3,ylab="",
             xaxt ="n",ylim=c(0,3))

text(3.9,2,"Null distribution based on unadjusted ABC posterior estimates",font=2,cex=1)
text(3.8,1,paste0("p-value=",specify_decimal(summary(abc_gof_test_unadj)$pvalue,3)),font=3,cex=1.5)

o<-par(mar=c(2,4,2,0))
plot.gfit_log(abc_gof_test_ridge,breaks=break_s,xlim=c(1,7.5),
              main="", xaxt ="n",ylab="",ylim=c(0,2.5))
text(3.8,2,"Null distribution based on ridge-adjusted posterior estimates",font=2,cex=1)
text(3.8,1,paste0("p-value=",specify_decimal(summary(abc_gof_test_ridge)$pvalue,4)),font=3,cex=1.5)
mtext(text = "Density",
      side = 2,
      line = 2.5,cex=1,font=2)

par(mar=c(4,4,0,2))
plot.gfit_log(abc_gof_test_lasso,breaks=break_s,xlim=c(1,7.5), xlab="",
              main="",ylab="",ylim=c(0,2.5))

mtext(text = "ABC goodness-of-fit test statistic",
      side = 1,
      line = 2.5,cex=1,font=2)

text(3.8,2,"Null distribution based on lasso-adjusted posterior estimates",font=2,cex=1)
text(3.8,1,paste0("p-value=",specify_decimal(summary(abc_gof_test_lasso)$pvalue,3)),font=3,cex=1.5)
par(o)

#Posterior distribution on original scale
Posterior_Ridge_adj_distn<- exp(Posterior_Ridge_adj_distn_log)

# Function to perform Region of Practical Equivalence (ROPE) and Highest Density Interval (HDI)
require(bayestestR)
ROPE_Cred_Int<- function(theta_distn_diff,parameter_labels, ci_percent=0.89){
    if(is.list(theta_distn_diff)==FALSE){
        sigma_d<- sd(theta_distn_diff)#standard deviation of differenced posterior samples
        output<- bayestestR::equivalence_test(theta_distn_diff, 
                #ROPE range is based on recommendation by Norman et al (2003)
                range =c(-.5*sigma_d,.5*sigma_d), ci = ci_percent,ci_method = "HDI")
    final_output<- cbind(parameter_labels,output);names(final_output)[1]<- "Parameter"
    return(final_output)
    }
    #theta_distn_diff= a list of posterior samples of differences of parameters of interest
    output<-list() #save ROPE+HDI results
    for(i in seq_along(parameter_labels)){
     sigma_d<- sd(theta_distn_diff[[i]])#standard deviation of differenced posterior samples
    output[[i]]<- bayestestR::equivalence_test(theta_distn_diff[[i]], 
                #ROPE range is based on recommendation by Norman et al (2003)
                range =c(-.5*sigma_d,.5*sigma_d), ci = ci_percent,ci_method = "HDI")
        }
    
     #Function returns ROPE interval, ROPE Percentage, ROPE equivalence decision
      # and the corresponding HDI 
    final_output<- do.call("rbind",output)
    final_output<- cbind(parameter_labels,final_output)
    names(final_output)[1]<- "Parameters"
    return(final_output)
}

Posterior_distn_adj500<- Posterior_Ridge_adj_distn

#Extracting corresponding adjusted posterior samples
b1_young_posterior<- Posterior_distn_adj500[, c(1,3,5)]
b1_young_diff<- NULL

parameter_labels<- c("b_11-b_21","b_11-b_31","b_21-b_31")
dim<- length(parameter_labels)


g<-0#initialise number of groups
for(i in 1:(dim-1)){
    for(j in (dim-1):dim){
        if(i!=j){
            print(paste("i=",i,"","j=",j))
            g<- g+1
            #Compute posterior of the difference under H0
            b1_young_diff[[g]]<-b1_young_posterior[,i]-b1_young_posterior[,j]
        }
    }
      
 }       
 
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=b1_young_diff,parameter_labels=parameter_labels, ci_percent=0.89)

#Extracting corresponding adjusted posterior samples
b2_old_posterior<- Posterior_distn_adj500[, c(2,4,6)]
b2_old_diff<- NULL

parameter_labels<- c("b_12-b_22","b_12-b_32","b_22-b_32")
dim<- length(parameter_labels)


g<-0#initialise number of groups
for(i in 1:(dim-1)){
    for(j in (dim-1):dim){
        if(i!=j){
            print(paste("i=",i,"","j=",j))
            g<- g+1
            #Compute posterior of the difference under H0
            b2_old_diff[[g]]<-b2_old_posterior[,i]-b2_old_posterior[,j]
        }
    }
      
 }       
 
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=b2_old_diff,parameter_labels=parameter_labels, ci_percent=0.89)

#Extracting corresponding adjusted posterior samples
b_posterior<- Posterior_distn_adj500[, 1:6]
b_diff<- NULL

parameter_labels<- c("b_11-b_12","b_21-b_22","b_31-b_32")
#Compute posterior of the difference under H0
b_diff[[1]]<- b_posterior[,1]-b_posterior[,2]
b_diff[[2]]<- b_posterior[,3]-b_posterior[,4]
b_diff[[3]]<- b_posterior[,5]-b_posterior[,6]
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=b_diff,parameter_labels=parameter_labels, ci_percent=0.89)

#Extracting corresponding adjusted posterior samples
d_nr_posterior<- Posterior_distn_adj500[, c(7,9,11)]
d_nr_diff<- NULL

parameter_labels<- c("d_11-d_21","d_11-d_31","d_21-d_31")
dim<- length(parameter_labels)


g<-0#initialise number of groups
for(i in 1:(dim-1)){
    for(j in (dim-1):dim){
        if(i!=j){
            print(paste("i=",i,"","j=",j))
            g<- g+1
            #Compute posterior of the difference under H0
            d_nr_diff[[g]]<-d_nr_posterior[,i]-d_nr_posterior[,j]
        }
    }
      
 }       
 
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=d_nr_diff,parameter_labels=parameter_labels, ci_percent=0.89)

#Extracting corresponding adjusted posterior samples
d_r_posterior<- Posterior_distn_adj500[, c(8,10,12)]
d_r_diff<- NULL

parameter_labels<- c("d_12-d_22","d_12-d_32","d_22-d_32")
dim<- length(parameter_labels)


g<-0#initialise number of groups
for(i in 1:(dim-1)){
    for(j in (dim-1):dim){
        if(i!=j){
            print(paste("i=",i,"","j=",j))
            g<- g+1
            #Compute posterior of the difference under H0
            d_r_diff[[g]]<-d_r_posterior[,i]-d_r_posterior[,j]
        }
    }
      
 }       
 
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=d_r_diff,parameter_labels=parameter_labels, ci_percent=0.89)

#Extracting corresponding adjusted posterior samples
d_posterior<- Posterior_distn_adj500[, 7:12]
d_diff<- NULL

parameter_labels<- c("d_11-d_12","d_21-d_22","d_31-d_32")
#Compute posterior of the difference under H0
d_diff[[1]]<- d_posterior[,1]-d_posterior[,2]
d_diff[[2]]<- d_posterior[,3]-d_posterior[,4]
d_diff[[3]]<- d_posterior[,5]-d_posterior[,6]
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=d_diff,parameter_labels=parameter_labels, ci_percent=0.89)

#Extracting corresponding adjusted posterior samples
e_posterior<- Posterior_distn_adj500[, c(20,21,22)]
e_diff<- NULL

parameter_labels<-c("epsilon_1-epsilon_2","epsilon_1-epsilon_3","epsilon_2-epsilon_3")
dim<- length(parameter_labels)


g<-0#initialise number of groups
for(i in 1:(dim-1)){
    for(j in (dim-1):dim){
        if(i!=j){
            print(paste("i=",i,"","j=",j))
            g<- g+1
            #Compute posterior of the difference under H0
            e_diff[[g]]<-e_posterior[,i]-e_posterior[,j]
        }
    }
      
 }       
 
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=e_diff,parameter_labels=parameter_labels, ci_percent=0.89)

#Extracting corresponding adjusted posterior samples
r_posterior<- Posterior_distn_adj500[, c(15,16,17)]
r_diff<- NULL

parameter_labels<-c("r_1-r_2","r_1-r_3","r_2-r_3")
dim<- length(parameter_labels)


g<-0#initialise number of groups
for(i in 1:(dim-1)){
    for(j in (dim-1):dim){
        if(i!=j){
            print(paste("i=",i,"","j=",j))
            g<- g+1
            #Compute posterior of the difference under H0
            r_diff[[g]]<-r_posterior[,i]-r_posterior[,j]
        }
    }
      
 }       
 
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=r_diff,parameter_labels=parameter_labels, ci_percent=0.89)

s1_posterior<- Posterior_distn_adj500[, 19]

parameter_labels<-c("s_1")
#Performing ROPE+HDI test
ROPE_Cred_Int(theta_distn_diff=s1_posterior,parameter_labels=parameter_labels, ci_percent=0.89)

#Simulations based on the unadjusted posterior##########################
rep<-1 #Number of replicates/repetition
output_sim_unadj<- NULL
set.seed(1234)
for(i in 1:rep){
    #set.seed(i)
    output_sim_unadj[[i]]<- SimGroup_tauleap(theta1=log(Parameter_estimates_unadj),
            fish_sex=fishSex,fish_type=Fish_stock,strain=Strain,fish_size=fishSize,error=0.01)
    }

#Simulations based on the Ridge adjusted posterior#########################

rep<-1 #Number of replicates/repetition
output_sim_ridge<- NULL
set.seed(1234)
for(i in 1:rep){
     #set.seed(i)
    output_sim_ridge[[i]]<- SimGroup_tauleap(theta1=log(Parameter_estimates_ridge),
            fish_sex=fishSex,fish_type=Fish_stock,strain=Strain,fish_size=fishSize,error=0.01)
    }

#Simulations based on the Lasso adjusted posterior
rep<- 1 # Number of replicates/repetition
output_sim_lasso<- NULL
set.seed(1234)
for(i in 1:rep){
     #set.seed(i)
    output_sim_lasso[[i]]<- SimGroup_tauleap(theta1=log(Parameter_estimates_lasso),
            fish_sex=fishSex,fish_type=Fish_stock,strain=Strain,fish_size=fishSize,error=0.01)
    }

Parasite_data_summary<- function(data_all_fish, observed_times= 1:9,
                        Total_fish=sum(unlist(numF)),
                        parasite_fish=parasite_fish,sim=TRUE,
                        fishSex=fishSex,fishID=fishID,
                        fishSize=fishSize,Strain=Strain,
                        Fish_stock=Fish_stock,Group){
    #Group= the comparable groups observed data vs the three ABC methods
   
    sum_func<- function(x) sum(x, na.rm=TRUE)
    #mean_func<- function(x) mean(x, na.rm=TRUE)
    parasites_data<- data.frame(matrix(NA,nrow=Total_fish, ncol=length(observed_times)+7)) 
    fish_index<- 0
    
        for(pf in 1:9){
          for(i in 1:numF[[pf]]){
              fish_index <- fish_index +1
              #Total number of parasites at each timepoint per fish
              if(sim==TRUE) parasites_per_fish<- apply(data_all_fish$pop_sim[[pf]][ i, , ], 2, sum_func)
              else if(sim==FALSE) parasites_per_fish<- apply(data_all_fish[[pf]][ i, , ], 2, sum_func)
         
                  parasites_data[fish_index , 1:9 ] <- as.vector( parasites_per_fish)
                  parasites_data[fish_index , 10  ] <- parasite_fish[pf]
                  parasites_data[fish_index , 11  ] <- fishSex[[pf]][i]
                  parasites_data[fish_index , 12  ] <- fishID[[pf]][i]
                  parasites_data[fish_index , 13  ] <- fishSize[[pf]][i]
                  parasites_data[fish_index , 14  ] <- Strain[[pf]][i]
                  parasites_data[fish_index , 15  ] <- Fish_stock[[pf]][i]
                  parasites_data[fish_index,  16  ] <- paste0(Group)

                     }
          }
      
    names(parasites_data)<- c(paste0("Parasites_t",observed_times), "Parafish_group","Sex",
                             "FishID","Fish_size","Parasite_strain","Fish_stock","Group")
    return(parasites_data)
}

Sim_data_unadj_reg<- NULL; Sim_data_ridge_reg<- NULL;Sim_data_lasso_reg<- NULL

for(i in 1:rep){
    #Simulations based on unadjusted posterior estimates
    Sim_data_unadj_reg[[i]]<- Parasite_data_summary(data_all_fish=output_sim_unadj[[i]], observed_times= 1:9,
                    Total_fish=sum(unlist(numF)),parasite_fish=parasite_fish,sim=TRUE,
                     fishSex=fishSex,fishID=fishID,
                        fishSize=fishSize,Strain=Strain,Fish_stock=Fish_stock,Group="Unadjusted ABC")
    
    #Simulations based on ridge posterior estimates
    Sim_data_ridge_reg[[i]]<- Parasite_data_summary(data_all_fish=output_sim_ridge[[i]], observed_times= 1:9,
                    Total_fish=sum(unlist(numF)),parasite_fish=parasite_fish,sim=TRUE,
                     fishSex=fishSex,fishID=fishID,
                        fishSize=fishSize,Strain=Strain,Fish_stock=Fish_stock,Group="Ridge adjustment")
    
    #Simulations based on lasso posterior estimates
    Sim_data_lasso_reg[[i]]<- Parasite_data_summary(data_all_fish=output_sim_lasso[[i]], observed_times= 1:9,
                    Total_fish=sum(unlist(numF)),parasite_fish=parasite_fish,sim=TRUE,
                     fishSex=fishSex,fishID=fishID,
                        fishSize=fishSize,Strain=Strain,Fish_stock=Fish_stock,Group="Lasso adjustment")
    
    }

Observed_data_reg<- Parasite_data_summary(data_all_fish=pop_obs, observed_times= 1:9,
                    Total_fish=sum(unlist(numF)),parasite_fish=parasite_fish,sim=FALSE,
                     fishSex=fishSex,fishID=fishID,
                fishSize=fishSize,Strain=Strain,Fish_stock=Fish_stock,Group="Observed data")


head(Observed_data_reg)

Combine_sim_obs_data_func<- function(obs_data,sim_unadj,sim_ridge,sim_lasso, rep=rep, combine_all=TRUE){
    Combine_sim_obs_data<- NULL
    for(i in 1:rep){
        Combine_sim_obs_data[[i]]<- rbind(obs_data,sim_unadj[[i]],sim_ridge[[i]],sim_lasso[[i]] )
        Combine_sim_obs_data[[i]]$Replicate_index<-  paste0(i)
        }
     if(combine_all==FALSE) return(Combine_sim_obs_data)
     else if( combine_all==TRUE) return(do.call("rbind",Combine_sim_obs_data))
}

#Combined data for mixed-effect regression model
Combine_sim_obs_data_reg<- Combine_sim_obs_data_func(obs_data=Observed_data_reg,sim_unadj= Sim_data_unadj_reg,
                    sim_ridge=Sim_data_ridge_reg,sim_lasso=Sim_data_lasso_reg, rep=rep, combine_all=TRUE)

dim(Combine_sim_obs_data_reg)

names(Combine_sim_obs_data_reg)

head(Combine_sim_obs_data_reg)

transform_structure<- function(data){
    data.timepoints<- NULL; times<- seq(1,17,by=2)
    
    for(t in 1:9){
        data.timepoints[[t]]<- data[, c(t,10:17)]
        data.timepoints[[t]][,1]<- log(data.timepoints[[t]][,1]+1) #on log scale
        names(data.timepoints[[t]])[1]<- "Parasites"
        data.timepoints[[t]]$Time<- time[t]
    }
    
    
    return(do.call("rbind",data.timepoints))
}

transdata_reg<- transform_structure(Combine_sim_obs_data_reg)
#Converting all character variables to factors
transdata_reg[sapply(transdata_reg, is.character)] <- lapply(transdata_reg[sapply(transdata_reg, is.character)], 
                                                           as.factor)



transdata_reg$Group<- relevel(transdata_reg$Group,ref="Observed data")
transdata_reg$Sex<- relevel(transdata_reg$Sex,ref="Female")
transdata_reg$Parasite_strain<- relevel(transdata_reg$Parasite_strain,ref="Gt")
transdata_reg$Fish_stock<- relevel(transdata_reg$Fish_stock,ref="UA")

head(transdata_reg)

#label.y = c(29, 35, 40)

p1<- transdata_reg %>%
  mutate(type=fct_reorder(as.factor(Time),Parasites),
        Group=fct_reorder(as.factor(Group),Parasites)) %>%
     ggplot()+geom_smooth(aes(x=Time, y=Parasites,color=Group,group=Group),method = "loess")+
labs(y="Parasite mean intensity") +
theme(axis.line = element_line(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),

        panel.background = element_blank())


p1+xlim(1,17)+facet_wrap(~Parasite_strain+Fish_stock,  ncol=3)+
  guides(color = guide_legend(title = "Comparable groups"))

transdata_reg_original<-transdata_reg
transdata_reg_original[,1]<- exp(transdata_reg_original[,1])#inverse log transformation

head(transdata_reg_original)

Fit_mixedmodel<- NULL #store fitted model

#Zero-inflated poisson mixed effect model
options(warn=-1)
Fit_mixedmodel[[1]] <- glmmTMB(Parasites~  Group+Parasite_strain+Fish_stock+Fish_size+
                               Sex+(1|FishID)+(1|Time)
                               ,data=transdata_reg_original,ziformula=~1,family=poisson)

#Zero-inflated negative binomial mixed effect model (Type 1 where NB1 (variance = μ + α*μ))
#where where μ is the mean, and α is the overdispersion parameter.
Fit_mixedmodel[[2]] <- glmmTMB(Parasites~  Group+Parasite_strain+Fish_stock+Fish_size+
                               Sex+(1|FishID)+(1|Time)
                               ,data=transdata_reg_original,ziformula=~1,family=nbinom1)

#Zero-inflated negative binomial mixed effect model (Type 2 where NB2 (variance = μ+α*μ^2))
#Note: Type 2 or NB2 is the standard form of negative binomial used to estimate data that are Poisson-overdispersed
Fit_mixedmodel[[3]] <- glmmTMB(Parasites~  Group+Parasite_strain+Fish_stock+Fish_size+
                               Sex+(1|FishID)+(1|Time)
                               ,data=transdata_reg_original,ziformula=~1,family=nbinom2)

# Poisson mixed effect model
Fit_mixedmodel[[4]] <- glmmTMB(Parasites~  Group+Parasite_strain+Fish_stock+Fish_size+
                               Sex+(1|FishID)+(1|Time)
                               ,data=transdata_reg_original,ziformula=~0,family=poisson)

#Negative Binomial mixed effect model (NB1)
Fit_mixedmodel[[5]] <- glmmTMB(Parasites~  Group+Parasite_strain+Fish_stock+Fish_size+
                               Sex+(1|FishID)+(1|Time)
                               ,data=transdata_reg_original,ziformula=~0,family=nbinom1)

#Negative Binomial mixed effect model (NB2)
Fit_mixedmodel[[6]] <- glmmTMB(Parasites~  Group+Parasite_strain+Fish_stock+Fish_size+
                               Sex+(1|FishID)+(1|Time),data=transdata_reg_original,ziformula=~0,family=nbinom2)

aic_values<- NULL; bic_values<- NULL

for(i in 1:6){
    print(paste("Model:", i))
    
    #ConRsq_values[[i]]<- MuMIn::r.squaredGLMM(Fit_mixedmodel[[i]])[1, ][2]
    #print(paste("Conditional R-square value=",ConRsq_values[[i]]))
    
   # MarginalRsq_values[[i]]<- MuMIn::r.squaredGLMM(Fit_mixedmodel[[i]])[1, ][1]
    #print(paste("Marginal R-square value=",MarginalRsq_values[[i]]))
    
    aic_values[[i]]<- AIC(Fit_mixedmodel[[i]])
    print(paste("AIC value=",aic_values[[i]]))
    
    
    bic_values[[i]]<- BIC(Fit_mixedmodel[[i]])
    print(paste("BIC value=",bic_values[[i]]))
}


paste("best fitted mixed model with the least AIC value is: Model ", which.min(unlist(aic_values)))
paste("best fitted mixed model with the least BIC value is: Model ", which.min(unlist(bic_values)))

summary(Fit_mixedmodel[[6]])

#Invisibly returns the web page style sheet as an external file (Best way of summarising GLMM results)
# Add show.std=TRUE for standardised results
sjPlot:: tab_model(Fit_mixedmodel[[6]],digits = 4)

#Abundance rate ratios
exp(confint(Fit_mixedmodel[[6]],level=.95))

sjPlot::plot_model(Fit_mixedmodel[[6]],type = "est",title="",axis.title="Parasite Abundance Rate Ratios",
                   show.values=TRUE,show.p=TRUE, sort.est = FALSE,
                  bpe = "median",dot.size=1.5,robust = T,
  show.data = T) + ###
theme(axis.line = element_line(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),

        panel.background = element_blank())

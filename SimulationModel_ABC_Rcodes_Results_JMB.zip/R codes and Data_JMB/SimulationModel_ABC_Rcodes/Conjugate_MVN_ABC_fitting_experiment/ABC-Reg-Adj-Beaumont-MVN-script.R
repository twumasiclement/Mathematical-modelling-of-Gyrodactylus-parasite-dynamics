require("kedd")

epanechnikov_kernel<- function(dist, delta){
   if(dist<=delta)  epa_kern<- (3 / (4 * delta)) * (1 - (dist / delta)^2)
   else if(dist>delta) epa_kern<-0
   return(epa_kern)
}


Post_Beaumont_reg_adj<- function(post_distn,summary_obs,Sigma_0) {
  # post_dtn is the posterior sample
  # w are weights across summary statistics for computing weighted distance
  no_of_parameters<- 6
  dimS<- length(summary_obs)#dimension of summaries
  posterior_mean_adj<- rep(NA,no_of_parameters) #storing adjusted posterior means
  #Combining the summary stats for the observed data for the parasite-fish groups
  m<- dim(post_distn)[1]# m=number of posterior samples
  d<- rep(0, m)# weighted distances given observed data
  p<- length(summary_obs) #dimension of summary statistics
  Unadj_dist<- post_distn
  X_Design_matrix<- matrix(NA, ncol=p,nrow=m) #design matrix
  S<-matrix(nrow=m,ncol=dimS) #storing simulated summaries
  # Weights based on Gaussian kernel for local-linear regression adjustment
  W<- matrix(0, ncol=m,nrow=m)
  X_bar=numeric(length=p) #saving weighted column means of design matrix 
  for (i in 1:m) {
    theta<- as.vector(unlist(post_distn[i,]))
    
    output<- Model_MVN(theta_vals=theta,n=1000,Sigma_0=Sigma_0)
    
    #Computing the summary stats for each simulation realisation
    S[i, ] <-  Summary_stats(data=output)
    diff<- S[i, ]-summary_obs
    X_Design_matrix[i, ]<- diff  #storing each row of design matrix X
  }
  
  # Computing weights based on
  #Storing the summary stats and distance (between summaries of observed and simulated data)
  w <-apply(S, 2, var, na.rm = TRUE)
  w<- w/sum(w) #normalised weight for computing distance
  
  for(i in 1:m) d[i] <- distance(Summary_sim=S[i, ],Summary_obs=summary_obs, weight=w)
  
 
  distances<-d
  #Adaptively choosing the bandwidth of the Gaussian or epanechnikov kernel based on the distances
  bandwidth<- kedd::h.amise(x=distances, deriv.order =0,kernel = c("epanechnikov"))$h
  #bandwidth<- KernSmooth::dpik(x=distances, kernel = "normal",scalest = "minim")
  #diag(W)<- guass_kernel(dist= distances,delta=sqrt(bandwidth))
  diag(W)<- epanechnikov_kernel(dist= distances,delta=bandwidth)

  theta_post<- as.matrix(post_distn)  
  weights<- diag(W)/sum(diag(W)) # (normalising) main diagonal of Weighting matrix
  
  #Transforming X and Y (posterior distribution and summary statistics)
  for(j in seq_along(posterior_mean_adj)){#For each jth model parameter, j=1,2,...23
    X<- cbind(1,X_Design_matrix)
    Y<- theta_post[ ,j]
    
  
    # calculating beta estimates of predictors
    alpha_beta_Beaumont <- solve(t(X) %*%W%*%X) %*% t(X)%*%W%*%Y
   
    
    # calculate intercept estimates (adjusted posterior mean estimates)
    alpha_estimate<- alpha_beta_Beaumont[1]
    posterior_mean_adj[j] <- exp(alpha_estimate)
    
    #Adjusting the posterior distribution
    beta_estimates<- alpha_beta_Beaumont[-1] 
    Unadj_dist[,j]<- post_distn[, j]- X_Design_matrix%*%beta_estimates
    
  }
  
  
  
  posterior_mean_uadj<-   apply(exp(post_distn),2,mean)
  Posterior_mean_output<- data.frame(Adj_posterior_mean=posterior_mean_adj,
                                     Uadj_posterior_mean=posterior_mean_uadj)
  
  

 
  
  #returns the design data matrix, adjusted & unadjusted
  # means, and the adjusted posterior distribution
  return(list(X_Design_matrix=X,Posterior_mean_output=Posterior_mean_output,Adjusted_posterior_dist=Unadj_dist))
}